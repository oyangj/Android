/*
 * Copyright (C) 2010-2017 Alibaba Group Holding Limited.
 */

package com.aliyun.svideo.media;

import java.util.List;


public class MediaCache {

    public MediaDir dir;
    public List<MediaInfo> list;
}
