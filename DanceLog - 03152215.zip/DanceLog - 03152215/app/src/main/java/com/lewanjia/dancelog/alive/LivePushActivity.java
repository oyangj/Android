package com.lewanjia.dancelog.alive;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.hardware.Camera;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alivc.component.custom.AlivcLivePushCustomDetect;
import com.alivc.component.custom.AlivcLivePushCustomFilter;
import com.alivc.live.detect.TaoFaceFilter;
import com.alivc.live.filter.TaoBeautyFilter;
import com.alivc.live.pusher.AlivcLivePushBGMListener;
import com.alivc.live.pusher.AlivcLivePushConfig;
import com.alivc.live.pusher.AlivcLivePushError;
import com.alivc.live.pusher.AlivcLivePushErrorListener;
import com.alivc.live.pusher.AlivcLivePushInfoListener;
import com.alivc.live.pusher.AlivcLivePushNetworkListener;
import com.alivc.live.pusher.AlivcLivePushStatsInfo;
import com.alivc.live.pusher.AlivcLivePusher;
import com.alivc.live.pusher.AlivcPreviewOrientationEnum;
import com.alivc.live.pusher.LogUtil;
import com.alivc.live.pusher.SurfaceStatus;
import com.facebook.drawee.view.SimpleDraweeView;
import com.gyf.immersionbar.ImmersionBar;
import com.lewanjia.dancelog.MyApplication;
import com.lewanjia.dancelog.R;
import com.lewanjia.dancelog.event.ShowPop;
import com.lewanjia.dancelog.http.UrlConstants;
import com.lewanjia.dancelog.model.BaseResult;
import com.lewanjia.dancelog.model.RoomUserInfo;
import com.lewanjia.dancelog.model.SubscribeNumInfo;
import com.lewanjia.dancelog.ui.views.ExitLiveDialog;
import com.lewanjia.dancelog.ui.views.ExitLiveSecondDialog;
import com.lewanjia.dancelog.utils.DataConstants;
import com.lewanjia.dancelog.utils.JsonUtils;
import com.lewanjia.dancelog.utils.LogUtils;
import com.lewanjia.dancelog.utils.ToastUtils;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

import static com.alivc.live.pusher.AlivcPreviewOrientationEnum.ORIENTATION_LANDSCAPE_HOME_LEFT;
import static com.alivc.live.pusher.AlivcPreviewOrientationEnum.ORIENTATION_LANDSCAPE_HOME_RIGHT;
import static com.alivc.live.pusher.AlivcPreviewOrientationEnum.ORIENTATION_PORTRAIT;

public class LivePushActivity extends BaseLiveActivity {


    private static final String TAG = "LivePushActivity";
    private static final int FLING_MIN_DISTANCE = 50;
    private static final int FLING_MIN_VELOCITY = 0;
    private final long REFRESH_INTERVAL = 1000;
    private static final String URL_KEY = "url_key";
    private static final String ASYNC_KEY = "async_key";
    private static final String AUDIO_ONLY_KEY = "audio_only_key";
    private static final String VIDEO_ONLY_KEY = "video_only_key";
    private static final String ORIENTATION_KEY = "orientation_key";
    private static final String CAMERA_ID = "camera_id";
    private static final String FLASH_ON = "flash_on";
    private static final String AUTH_TIME = "auth_time";
    private static final String PRIVACY_KEY = "privacy_key";
    private static final String MIX_EXTERN = "mix_extern";
    private static final String MIX_MAIN = "mix_main";
    public static final int REQ_CODE_PUSH = 0x1112;
    public static final int CAPTURE_PERMISSION_REQUEST_CODE = 0x1123;

    public SurfaceView mPreviewView;
    //    private GestureDetector mDetector;
//    private ScaleGestureDetector mScaleDetector;
    private AlivcLivePushConfig mAlivcLivePushConfig;

    private AlivcLivePusher mAlivcLivePusher = null;
    private String mPushUrl = null;

    private boolean mAsync = false;
    private boolean mAudioOnly = false;
    private boolean mVideoOnly = false;
    private int mOrientation = ORIENTATION_PORTRAIT.ordinal();

    private SurfaceStatus mSurfaceStatus = SurfaceStatus.UNINITED;
    //    private Handler mHandler = new Handler();
    private boolean isPause = false;

    private int mCameraId = Camera.CameraInfo.CAMERA_FACING_FRONT;
    private boolean mFlash = false;
    private boolean mMixExtern = false;
    private boolean mMixMain = false;
    AlivcLivePushStatsInfo alivcLivePushStatsInfo = null;
    TaoBeautyFilter taoBeautyFilter;

    TaoFaceFilter taoFaceFilter;

    private String mAuthTime = "";
    private String mPrivacyKey = "";


    private ConnectivityChangedReceiver mChangedReceiver = new ConnectivityChangedReceiver();
    private boolean videoThreadOn = false;
    private boolean audioThreadOn = false;

    private int mNetWork = 0;

    private String mAuthString = "?auth_key=%1$d-%2$d-%3$d-%4$s";
    private String mMd5String = "%1$s-%2$d-%3$d-%4$d-%5$s";
    private String mTempUrl = null;

    SimpleDraweeView simpleDraweeView;
    TextView tvTop;
    TextView tvBottom;
    int numSub;
    boolean isMirror = false;
    Timer timerNum;
    private RelativeLayout rl_load;

    public static void start(Context context, String url, String id, String pic, int num) {
        Intent intent = new Intent(context, LivePushActivity.class);
        intent.putExtra(URL_KEY, url);
        intent.putExtra("room_id", id);
        intent.putExtra("pic", pic);
        intent.putExtra("num", num);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        mPushUrl = getIntent().getStringExtra(URL_KEY);
        mAsync = getIntent().getBooleanExtra(ASYNC_KEY, false);
        mAudioOnly = getIntent().getBooleanExtra(AUDIO_ONLY_KEY, false);
        mVideoOnly = getIntent().getBooleanExtra(VIDEO_ONLY_KEY, false);
        mOrientation = getIntent().getIntExtra(ORIENTATION_KEY, ORIENTATION_PORTRAIT.ordinal());
        mCameraId = getIntent().getIntExtra(CAMERA_ID, Camera.CameraInfo.CAMERA_FACING_FRONT);
        mFlash = getIntent().getBooleanExtra(FLASH_ON, false);
        mAuthTime = getIntent().getStringExtra(AUTH_TIME);
        mPrivacyKey = getIntent().getStringExtra(PRIVACY_KEY);
        mMixExtern = getIntent().getBooleanExtra(MIX_EXTERN, false);
        mMixMain = getIntent().getBooleanExtra(MIX_MAIN, false);
        setOrientation(mOrientation);
        setContentView(R.layout.activity_push);
        roomid = getIntent().getStringExtra("room_id");
        mAlivcLivePushConfig = new AlivcLivePushConfig();
        mAlivcLivePusher = new AlivcLivePusher();
        init();
        initView();
        ImmersionBar.with(this).fullScreen(true).transparentBar().init();
//        SoftHideKeyBoardUtil.assistActivity(this);

        try {
            mAlivcLivePusher.init(getApplicationContext(), mAlivcLivePushConfig);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }

        if (mAlivcLivePusher != null) {
            mAlivcLivePusher.setLivePushInfoListener(mPushInfoListener);
            mAlivcLivePusher.setLivePushErrorListener(mPushErrorListener);
            mAlivcLivePusher.setLivePushNetworkListener(mPushNetworkListener);
            mAlivcLivePusher.setLivePushBGMListener(mPushBGMListener);
        }

        mAlivcLivePusher.setCustomDetect(new AlivcLivePushCustomDetect() {
            @Override
            public void customDetectCreate() {
                taoFaceFilter = new TaoFaceFilter(getApplicationContext());
                taoFaceFilter.customDetectCreate();
            }

            @Override
            public long customDetectProcess(long data, int width, int height, int rotation, int format, long extra) {
                if (taoFaceFilter != null) {
                    return taoFaceFilter.customDetectProcess(data, width, height, rotation, format, extra);
                }
                return 0;
            }

            @Override
            public void customDetectDestroy() {
                if (taoFaceFilter != null) {
                    taoFaceFilter.customDetectDestroy();
                }
            }
        });
        mAlivcLivePusher.setCustomFilter(new AlivcLivePushCustomFilter() {
            @Override
            public void customFilterCreate() {
                taoBeautyFilter = new TaoBeautyFilter();
                taoBeautyFilter.customFilterCreate();
            }

            @Override
            public void customFilterUpdateParam(float fSkinSmooth, float fWhiten, float fWholeFacePink, float fThinFaceHorizontal, float fCheekPink, float fShortenFaceVertical, float fBigEye) {
                if (taoBeautyFilter != null) {
                    taoBeautyFilter.customFilterUpdateParam(fSkinSmooth, fWhiten, fWholeFacePink, fThinFaceHorizontal, fCheekPink, fShortenFaceVertical, fBigEye);
                }
            }

            @Override
            public void customFilterSwitch(boolean on) {
                if (taoBeautyFilter != null) {
                    taoBeautyFilter.customFilterSwitch(on);
                }
            }

            @Override
            public int customFilterProcess(int inputTexture, int textureWidth, int textureHeight, long extra) {
                if (taoBeautyFilter != null) {
                    return taoBeautyFilter.customFilterProcess(inputTexture, textureWidth, textureHeight, extra);
                }
                return inputTexture;
            }

            @Override
            public void customFilterDestroy() {
                if (taoBeautyFilter != null) {
                    taoBeautyFilter.customFilterDestroy();
                }
                taoBeautyFilter = null;
            }
        });

//        mScaleDetector = new ScaleGestureDetector(getApplicationContext(), mScaleGestureDetector);
//        mDetector = new GestureDetector(getApplicationContext(), mGestureDetector);
        mNetWork = NetWorkUtils.getAPNType(this);
        IntentFilter filter = new IntentFilter();
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(mChangedReceiver, filter);

        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exit();
            }
        });

        timerNum();
    }


    public void timerNum() {
        try {
            timerNum = new Timer();
            timerNum.schedule(new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            sendRequest(getRequestUrl(UrlConstants.GET_USER_SUSCRIBE_NUM), null);
                        }
                    });
                }
            }, 0, 20000);
        } catch (Exception e) {

        }
    }

    int num = 0;

    @Override
    public void onRequestSuccess(String url, String result, Object... extra) {
        super.onRequestSuccess(url, result, extra);
        if (getRequestUrl(UrlConstants.GET_ROOM_USER).equals(url)) {
            String type = (String) extra[0].toString();
            if (type.equals(TYPE_OFFLINE)) {
                RoomUserInfo roomUserInfo = JsonUtils.toBean(result, RoomUserInfo.class);
                if (roomUserInfo != null) {
                    if (roomUserInfo.getData() != null) {
                        if (roomUserInfo.getData().getList() != null) {
                            offLineNum = roomUserInfo.getData().getList().getTotal_count();
                            if (roomUserInfo.getData().getList().getUsers() != null &&
                                    roomUserInfo.getData().getList().getUsers().size() > 0) {
                                if (DataConstants.OFFLINE_CHAT_LIST != null
                                        && DataConstants.OFFLINE_CHAT_LIST.size() > 0) {
                                    DataConstants.OFFLINE_CHAT_LIST.clear();
                                }
                                DataConstants.OFFLINE_CHAT_LIST.addAll(roomUserInfo.getData().getList().getUsers());
                            }
                        }
                    }
                }
                num++;

            }
            if (num == 2) {
                showDialog();
                num = 0;
            }
        } else if (getRequestUrl(UrlConstants.SAVE_VISIT_LIVE_RECORD).equals(url)) {
//            doRequestRoomNum(TYPE_OFFLINE);
//            doRequestRoomNum(TYPE_ONLINE);
        } else if (getRequestUrl(UrlConstants.CLOSE_LIVE).equals(url)) {
            BaseResult baseResult = JsonUtils.toBean(result, BaseResult.class);
            if (baseResult != null) {
                if (baseResult.getResult() == 200) {
                    doSendExit();
                    destory();
                    finish();
                } else {
                    if (!TextUtils.isEmpty(baseResult.getMsg())) {
                        ToastUtils.show(LivePushActivity.this, baseResult.getMsg());
                    }
                }

            }
        } else if (getRequestUrl(UrlConstants.GET_USER_SUSCRIBE_NUM).equals(url)) {
            SubscribeNumInfo subscribeNumInfo = JsonUtils.toBean(result, SubscribeNumInfo.class);
            if (subscribeNumInfo != null) {
                if (subscribeNumInfo.getData() != null) {
                    tvBottom.setText(subscribeNumInfo.getData().getSubscribe_num() + "人");
                }
            }
        } else if (getRequestUrl(UrlConstants.GET_LIVE_PAY_USER).equals(url)) {
            RoomUserInfo roomUserInfo = JsonUtils.toBean(result, RoomUserInfo.class);
            //先获取网络的
            if (roomUserInfo != null) {
                if (roomUserInfo.getData() != null) {
                    if (roomUserInfo.getData().getList() != null) {
                        onLineNum = roomUserInfo.getData().getList().getTotal_count();
                        if (roomUserInfo.getData().getList().getUsers() != null &&
                                roomUserInfo.getData().getList().getUsers().size() > 0) {
                            if (DataConstants.ONLINE_CHAT_LIST != null
                                    && DataConstants.ONLINE_CHAT_LIST.size() > 0) {
                                DataConstants.ONLINE_CHAT_LIST.clear();
                            }
                            DataConstants.ONLINE_CHAT_LIST.addAll(roomUserInfo.getData().getList().getUsers());
                        }
                    }
                }
            }
            num++;

            if (num == 2) {
                showDialog();
                num = 0;
            }
        }
    }

    @Override
    public void onRequestFailure(String url, int errorCode, String error, String result, Object... extra) {
        super.onRequestFailure(url, errorCode, error, result, extra);
        if (getRequestUrl(UrlConstants.CLOSE_LIVE).equals(url)) {
            BaseResult baseResult = JsonUtils.toBean(result, BaseResult.class);
            if (!TextUtils.isEmpty(baseResult.getMsg()) && baseResult != null) {
                ToastUtils.show(LivePushActivity.this, baseResult.getMsg());
            }
        }
    }

    private void push() {
        if (!NetWorkUtils.isNetworkConnected(this)) {
            ToastUtils.show(LivePushActivity.this, getString(R.string.request_error_internet));
            return;
        }
        if (mAsync) {
            mAlivcLivePusher.startPushAysnc(getAuthString(mAuthTime));
        } else {
            mAlivcLivePusher.startPush(getAuthString(mAuthTime));
        }
        if (mMixExtern) {
            //startMixPCM(getActivity());
        } else if (mMixMain) {
            startPCM();
        }
    }

    private String getAuthString(String time) {
        if (time == null) {
            mTempUrl = mPushUrl;
        } else {
            if (!TextUtils.isEmpty(time) && !TextUtils.isEmpty(mPrivacyKey)) {
                long tempTime = (System.currentTimeMillis() + Integer.valueOf(time)) / 1000;
                String tempprivacyKey = String.format(mMd5String, getUri(mPushUrl), tempTime, 0, 0, mPrivacyKey);
                String auth = String.format(mAuthString, tempTime, 0, 0, getMD5(tempprivacyKey));
                mTempUrl = mPushUrl + auth;
            } else {
                mTempUrl = mPushUrl;
            }
        }
        return mTempUrl;
    }

    private String getMD5(String string) {

        byte[] hash;

        try {
            hash = MessageDigest.getInstance("MD5").digest(string.getBytes("UTF-8"));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        }

        StringBuilder hex = new StringBuilder(hash.length * 2);
        for (byte b : hash) {
            if ((b & 0xFF) < 0x10) {
                hex.append("0");
            }
            hex.append(Integer.toHexString(b & 0xFF));
        }

        return hex.toString();
    }

    private String getUri(String url) {
        String result = "";
        String temp = url.substring(7);
        if (temp != null && !TextUtils.isEmpty(temp)) {
            result = temp.substring(temp.indexOf("/"));
        }
        return result;
    }

    private void startPCM() {
        new ScheduledThreadPoolExecutor(1, new ThreadFactory() {
            private AtomicInteger atoInteger = new AtomicInteger(0);

            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setName("LivePushActivity-readPCM-Thread" + atoInteger.getAndIncrement());
                return t;
            }
        }).execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                audioThreadOn = true;
                byte[] pcm;
                int allSended = 0;
                int sizePerSecond = 44100 * 2;
                InputStream myInput = null;
                OutputStream myOutput = null;
                boolean reUse = false;
                long startPts = System.nanoTime() / 1000;
                try {
                    File f = new File("/sdcard/alivc_resource/441.pcm");
                    myInput = new FileInputStream(f);
                    byte[] buffer = new byte[2048];
                    int length = myInput.read(buffer, 0, 2048);
                    while (length > 0 && audioThreadOn) {
                        long pts = System.nanoTime() / 1000;
                        mAlivcLivePusher.inputStreamAudioData(buffer, length, 44100, 1, pts);
                        allSended += length;
                        if ((allSended * 1000000L / sizePerSecond - 50000) > (pts - startPts)) {
                            try {
                                Thread.sleep(45);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                        length = myInput.read(buffer);
                        if (length < 2048) {
                            myInput.close();
                            myInput = new FileInputStream(f);
                            length = myInput.read(buffer);
                        }
                        try {
                            Thread.sleep(3);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    myInput.close();
                    audioThreadOn = false;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void stop() {
        try {
            if (mAlivcLivePusher != null) {
                mAlivcLivePusher.stopPush();
            }
            stopPcm();
        } catch (Exception e) {

        }

    }

    public void initView() {
        rl_load = findViewById(R.id.rl_load);
        simpleDraweeView = findViewById(R.id.iv);
        tvTop = findViewById(R.id.tv_top);
        tvBottom = findViewById(R.id.tv_bottom);
        numSub = getIntent().getIntExtra("num", 0);
        if (!TextUtils.isEmpty(MyApplication.getInstance().getHeaderUrl())) {
            simpleDraweeView.setImageURI(Uri.parse(MyApplication.getInstance().getHeaderUrl()));
        }
        if (!TextUtils.isEmpty(MyApplication.getInstance().getUserName())) {
            tvTop.setText(MyApplication.getInstance().getUserName());
        }
        tvBottom.setText(numSub + "人");
        mPreviewView = (SurfaceView) findViewById(R.id.preview_view);
        mPreviewView.getHolder().addCallback(mCallback);
        mPreviewView.setZOrderOnTop(true);
        mPreviewView.setZOrderMediaOverlay(true);
        findViewById(R.id.iv_mirror).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mAlivcLivePusher != null) {
                    isMirror = !isMirror;
                    mAlivcLivePusher.setPreviewMirror(isMirror);
//                    mAlivcLivePushConfig.setPreviewMirror(isMirror);
//                    mAlivcLivePushConfig.setPushMirror(isMirror);

                    LogUtils.i("hrx", "--isMirror--" + isMirror);
                }
            }
        });
        findViewById(R.id.ll_mirror).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mAlivcLivePusher != null) {
                    isMirror = !isMirror;
                    mAlivcLivePusher.setPreviewMirror(isMirror);
//                    mAlivcLivePushConfig.setPreviewMirror(isMirror);
//                    mAlivcLivePushConfig.setPushMirror(isMirror);

                    LogUtils.i("hrx", "--isMirror--" + isMirror);
                }
            }
        });
//        mPreviewView.getHolder().setFixedSize(DeviceUtils.getResolution(this)[0], DeviceUtils.getResolution(this)[1]);
//        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) mPreviewView.getLayoutParams();
//        int[] device = DeviceUtils.getResolution(LivePushActivity.this);
//        layoutParams.height = RelativeLayout.LayoutParams.MATCH_PARENT;
//        layoutParams.width = RelativeLayout.LayoutParams.MATCH_PARENT;
//        mPreviewView.setLayoutParams(layoutParams);
    }


    private void setOrientation(int orientation) {
        if (orientation == ORIENTATION_PORTRAIT.ordinal()) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else if (orientation == ORIENTATION_LANDSCAPE_HOME_RIGHT.ordinal()) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        } else if (orientation == ORIENTATION_LANDSCAPE_HOME_LEFT.ordinal()) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE);
        }
    }

    private GestureDetector.OnGestureListener mGestureDetector = new GestureDetector.OnGestureListener() {
        @Override
        public boolean onDown(MotionEvent motionEvent) {
            return false;
        }

        @Override
        public void onShowPress(MotionEvent motionEvent) {

        }

        @Override
        public boolean onSingleTapUp(MotionEvent motionEvent) {
            if (mPreviewView.getWidth() > 0 && mPreviewView.getHeight() > 0) {
                float x = motionEvent.getX() / mPreviewView.getWidth();
                float y = motionEvent.getY() / mPreviewView.getHeight();
                try {
                    mAlivcLivePusher.focusCameraAtAdjustedPoint(x, y, true);
                } catch (IllegalStateException e) {

                }
            }
            return true;
        }

        @Override
        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
            return false;
        }

        @Override
        public void onLongPress(MotionEvent motionEvent) {

        }

        @Override
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
            if (motionEvent == null || motionEvent1 == null) {
                return false;
            }
            if (motionEvent.getX() - motionEvent1.getX() > FLING_MIN_DISTANCE
                    && Math.abs(v) > FLING_MIN_VELOCITY) {
                // Fling left
            } else if (motionEvent1.getX() - motionEvent.getX() > FLING_MIN_DISTANCE
                    && Math.abs(v) > FLING_MIN_VELOCITY) {
                // Fling right
            }
            return false;
        }
    };

    private float scaleFactor = 1.0f;
    private ScaleGestureDetector.OnScaleGestureListener mScaleGestureDetector = new ScaleGestureDetector.OnScaleGestureListener() {
        @Override
        public boolean onScale(ScaleGestureDetector scaleGestureDetector) {
            if (scaleGestureDetector.getScaleFactor() > 1) {
                scaleFactor += 0.5;
            } else {
                scaleFactor -= 2;
            }
            if (scaleFactor <= 1) {
                scaleFactor = 1;
            }
            try {
                if (scaleFactor >= mAlivcLivePusher.getMaxZoom()) {
                    scaleFactor = mAlivcLivePusher.getMaxZoom();
                }
                mAlivcLivePusher.setZoom((int) scaleFactor);

            } catch (IllegalStateException e) {

            }
            return false;
        }

        @Override
        public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
            return true;
        }

        @Override
        public void onScaleEnd(ScaleGestureDetector scaleGestureDetector) {

        }
    };

    SurfaceHolder.Callback mCallback = new SurfaceHolder.Callback() {
        @Override
        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            if (mSurfaceStatus == SurfaceStatus.UNINITED) {
                mSurfaceStatus = SurfaceStatus.CREATED;
                if (mAlivcLivePusher != null) {

                    try {
                        if (mAsync) {
                            mAlivcLivePusher.startPreviewAysnc(mPreviewView);
                        } else {
                            mAlivcLivePusher.startPreview(mPreviewView);
                        }
                        if (mAlivcLivePushConfig.isExternMainStream()) {
                            startYUV(getApplicationContext());
                        }

                    } catch (IllegalArgumentException e) {
                        e.toString();
                    } catch (IllegalStateException e) {
                        e.toString();
                    }
                }
                push();
            } else if (mSurfaceStatus == SurfaceStatus.DESTROYED) {
                mSurfaceStatus = SurfaceStatus.RECREATED;
            }
        }

        @Override
        public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {
            mSurfaceStatus = SurfaceStatus.CHANGED;

        }

        @Override
        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            mSurfaceStatus = SurfaceStatus.DESTROYED;
        }
    };

    public static void startActivity(Activity activity, AlivcLivePushConfig alivcLivePushConfig, String url, boolean async, boolean audioOnly, boolean videoOnly, AlivcPreviewOrientationEnum orientation, int cameraId, boolean isFlash, String authTime, String privacyKey, boolean mixExtern, boolean mixMain) {
        Intent intent = new Intent(activity, LivePushActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable(AlivcLivePushConfig.CONFIG, alivcLivePushConfig);
        bundle.putString(URL_KEY, url);
        bundle.putBoolean(ASYNC_KEY, async);
        bundle.putBoolean(AUDIO_ONLY_KEY, audioOnly);
        bundle.putBoolean(VIDEO_ONLY_KEY, videoOnly);
        bundle.putInt(ORIENTATION_KEY, orientation.ordinal());
        bundle.putInt(CAMERA_ID, cameraId);
        bundle.putBoolean(FLASH_ON, isFlash);
        bundle.putString(AUTH_TIME, authTime);
        bundle.putString(PRIVACY_KEY, privacyKey);
        bundle.putBoolean(MIX_EXTERN, mixExtern);
        bundle.putBoolean(MIX_MAIN, mixMain);
        intent.putExtras(bundle);
        activity.startActivityForResult(intent, REQ_CODE_PUSH);
    }

    @Override
    protected void onResume() {
        super.onResume();
//        doRequestRoomNum(TYPE_ONLINE);
//        doRequestRoomNum(TYPE_OFFLINE);

        if (mAlivcLivePusher != null) {
            try {
                if (!isPause) {
                    if (mAsync) {
                        mAlivcLivePusher.resumeAsync();
                    } else {
                        mAlivcLivePusher.resume();
                    }
                }
            } catch (IllegalStateException e) {
                e.printStackTrace();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mAlivcLivePusher != null) {
            try {
//                if(mAlivcLivePusher != null/*.isPushing()*/) {
//                    mAlivcLivePusher.pause();
//                }
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onDestroy() {


        super.onDestroy();
    }

    public void destory() {
        try {
            videoThreadOn = false;
            audioThreadOn = false;
            if (mAlivcLivePusher != null) {
                // 停止推流

                try {
                    mAlivcLivePusher.stopPush();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                // 停止预览
                try {
                    mAlivcLivePusher.stopPreview();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                // 释放推流
                mAlivcLivePusher.destroy();
                mAlivcLivePusher.setLivePushInfoListener(null);
                mAlivcLivePusher = null;
            }
            try {
                if (mChangedReceiver != null) {
                    unregisterReceiver(mChangedReceiver);
                }
                if (timerNum != null) {
                    timerNum.cancel();
                    timerNum = null;
                }
            } catch (Exception e) {

            }

            mPreviewView = null;
//            mDetector = null;
//            mScaleDetector = null;
            mAlivcLivePushConfig = null;
            alivcLivePushStatsInfo = null;
        } catch (Exception e) {
            LogUtils.i("hrx", "-push999--" + e.getMessage());
        }
    }


    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        AlivcPreviewOrientationEnum orientationEnum;
        if (mAlivcLivePusher != null) {
            switch (rotation) {
                case Surface.ROTATION_0:
                    orientationEnum = ORIENTATION_PORTRAIT;
                    break;
                case Surface.ROTATION_90:
                    orientationEnum = ORIENTATION_LANDSCAPE_HOME_RIGHT;
                    break;
                case Surface.ROTATION_270:
                    orientationEnum = ORIENTATION_LANDSCAPE_HOME_LEFT;
                    break;
                default:
                    orientationEnum = ORIENTATION_PORTRAIT;
                    break;
            }
            try {
                mAlivcLivePusher.setPreviewOrientation(orientationEnum);
            } catch (IllegalStateException e) {

            }
        }
    }

    public AlivcLivePusher getLivePusher() {
        return this.mAlivcLivePusher;
    }

    public SurfaceView getPreviewView() {
        return this.mPreviewView;
    }


    private Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
            LogUtil.d(TAG, "====== mRunnable run ======");

            new AsyncTask<AlivcLivePushStatsInfo, Void, AlivcLivePushStatsInfo>() {
                @Override
                protected AlivcLivePushStatsInfo doInBackground(AlivcLivePushStatsInfo... alivcLivePushStatsInfos) {
                    try {
                        alivcLivePushStatsInfo = mAlivcLivePusher.getLivePushStatsInfo();
                    } catch (IllegalStateException e) {

                    }
                    return alivcLivePushStatsInfo;
                }

                @Override
                protected void onPostExecute(AlivcLivePushStatsInfo alivcLivePushStatsInfo) {
                    super.onPostExecute(alivcLivePushStatsInfo);

//                    mHandler.postDelayed(mRunnable, REFRESH_INTERVAL);
                }
            }.execute();
        }
    };

    public interface PauseState {
        void updatePause(boolean state);
    }

    private PauseState mStateListener = new PauseState() {
        @Override
        public void updatePause(boolean state) {
            isPause = state;
        }
    };

    class ConnectivityChangedReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            if (intent.getAction().equals(ConnectivityManager.CONNECTIVITY_ACTION)) {

                if (mNetWork != NetWorkUtils.getAPNType(context)) {
                    mNetWork = NetWorkUtils.getAPNType(context);
                    if (mAlivcLivePusher != null) {
                        if (mAlivcLivePusher.isPushing()) {
                            try {
                                mAlivcLivePusher.reconnectPushAsync(null);
                            } catch (IllegalStateException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }

        }
    }

    public void startYUV(final Context context) {
        new ScheduledThreadPoolExecutor(1, new ThreadFactory() {
            private AtomicInteger atoInteger = new AtomicInteger(0);

            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setName("LivePushActivity-readYUV-Thread" + atoInteger.getAndIncrement());
                return t;
            }
        }).execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                videoThreadOn = true;
                byte[] yuv;
                InputStream myInput = null;
                try {
                    File f = new File(Environment.getExternalStorageDirectory().getPath() + File.separator + "alivc_resource/capture0.yuv");
                    myInput = new FileInputStream(f);
                    byte[] buffer = new byte[1280 * 720 * 3 / 2];
                    int length = myInput.read(buffer);
                    //发数据
                    while (length > 0 && videoThreadOn) {
                        mAlivcLivePusher.inputStreamVideoData(buffer, 720, 1280, 720, 1280 * 720 * 3 / 2, System.nanoTime() / 1000, 0);
                        try {
                            Thread.sleep(40);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        //发数据
                        length = myInput.read(buffer);
                        if (length <= 0) {
                            myInput.close();
                            myInput = new FileInputStream(f);
                            length = myInput.read(buffer);
                        }
                    }
                    myInput.close();
                    videoThreadOn = false;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void stopYUV() {
        videoThreadOn = false;
    }

    private void stopPcm() {
        audioThreadOn = false;
    }

    AlivcLivePushInfoListener mPushInfoListener = new AlivcLivePushInfoListener() {
        @Override
        public void onPreviewStarted(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onPreviewStarted");
        }

        @Override
        public void onPreviewStoped(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onPreviewStoped");
        }

        @Override
        public void onPushStarted(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onPushStarted");
        }

        @Override
        public void onFirstAVFramePushed(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onFirstAVFramePushed");
        }

        @Override
        public void onPushPauesed(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onPushPauesed");
        }

        @Override
        public void onPushResumed(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onPushResumed");
        }

        @Override
        public void onPushStoped(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onPushStoped");
        }

        /**
         * 推流重启通知
         *
         * @param pusher AlivcLivePusher实例
         */
        @Override
        public void onPushRestarted(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onPushRestarted");
        }

        @Override
        public void onFirstFramePreviewed(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onFirstFramePreviewed");
        }

        @Override
        public void onDropFrame(AlivcLivePusher pusher, int countBef, int countAft) {
            LogUtils.i("hrx", "-->>onDropFrame" + ", 丢帧前：" + countBef + ", 丢帧后：" + countAft);
        }

        @Override
        public void onAdjustBitRate(AlivcLivePusher pusher, int curBr, int targetBr) {
            LogUtils.i("hrx", "-->>onAdjustBitRate" + ", 当前码率：" + curBr + "Kps, 目标码率：" + targetBr + "Kps");
        }

        @Override
        public void onAdjustFps(AlivcLivePusher pusher, int curFps, int targetFps) {
            LogUtils.i("hrx", "-->>onAdjustFps" + ", 当前帧率：" + curFps + ", 目标帧率：" + targetFps);
        }
    };

    AlivcLivePushErrorListener mPushErrorListener = new AlivcLivePushErrorListener() {

        @Override
        public void onSystemError(AlivcLivePusher livePusher, AlivcLivePushError error) {
            LogUtils.i("hrx", "-->>onSystemError" + error.toString());
        }

        @Override
        public void onSDKError(AlivcLivePusher livePusher, AlivcLivePushError error) {
            if (error != null) {
                LogUtils.i("hrx", "-->>onSDKError" + error.toString());
            }
        }
    };

    AlivcLivePushNetworkListener mPushNetworkListener = new AlivcLivePushNetworkListener() {
        @Override
        public void onNetworkPoor(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onNetworkPoor" + pusher.toString());
        }

        @Override
        public void onNetworkRecovery(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onNetworkRecovery" + pusher.toString());
        }

        @Override
        public void onReconnectStart(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onReconnectStart" + pusher.toString());
        }

        @Override
        public void onReconnectFail(AlivcLivePusher pusher) {

            LogUtils.i("hrx", "-->>onReconnectFail" + pusher.toString());
        }

        @Override
        public void onReconnectSucceed(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onReconnectSucceed" + pusher.toString());
        }

        @Override
        public void onSendDataTimeout(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onSendDataTimeout" + pusher.toString());
        }

        @Override
        public void onConnectFail(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onConnectFail" + pusher.toString());
        }

        @Override
        public void onConnectionLost(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onConnectionLost推流已断开");
        }

        @Override
        public String onPushURLAuthenticationOverdue(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onPushURLAuthenticationOverdue流即将过期，请更换url");
            return getAuthString(mAuthTime);
        }

        @Override
        public void onSendMessage(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onSendMessage" + pusher.toString());
        }

        @Override
        public void onPacketsLost(AlivcLivePusher pusher) {
            LogUtils.i("hrx", "-->>onPacketsLost推流丢包通知");
        }
    };

    private AlivcLivePushBGMListener mPushBGMListener = new AlivcLivePushBGMListener() {
        @Override
        public void onStarted() {
            LogUtils.i("hrx", "-->>onStarted");
        }

        @Override
        public void onStoped() {
            LogUtils.i("hrx", "-->>onStoped");
        }

        @Override
        public void onPaused() {
            LogUtils.i("hrx", "-->>onPaused");
        }

        @Override
        public void onResumed() {
            LogUtils.i("hrx", "-->>onResumed");
        }

        @Override
        public void onProgress(final long progress, final long duration) {
        }

        @Override
        public void onCompleted() {
            LogUtils.i("hrx", "-->>onCompleted");
        }

        @Override
        public void onDownloadTimeout() {
            LogUtils.i("hrx", "-->>onDownloadTimeout");
        }

        @Override
        public void onOpenFailed() {
            LogUtils.i("hrx", "-->>onOpenFailed");
        }
    };


    //退出弹窗
    ExitLiveDialog exitLiveDialog;

    @Override
    public void exit() {
        exitLiveDialog = new ExitLiveDialog(LivePushActivity.this, R.style.mydialog);
        exitLiveDialog.createDialog();
        exitLiveDialog.setOnClick(new ExitLiveDialog.OnClick() {
            @Override
            public void onClick(View view, boolean isSure) {

            }

            @Override
            public void onSure(View view) {
                exitSecondExit();

//                if (exitLiveDialog != null) {
//                    exitLiveDialog.dismiss();
//                    exitLiveDialog = null;
//                }
//                destory();
//                finish();
            }
        });
        exitLiveDialog.show();
    }

    ExitLiveSecondDialog exitLiveSecondDialog;

    public void exitSecondExit() {
        exitLiveSecondDialog = new ExitLiveSecondDialog(LivePushActivity.this, R.style.mydialog);
        exitLiveSecondDialog.createDialog();
        exitLiveSecondDialog.setOnClick(new ExitLiveSecondDialog.OnClick() {
            @Override
            public void onClick(View view, boolean isSure) {

            }

            @Override
            public void onSure(View view) {
                if (exitLiveSecondDialog != null) {
                    exitLiveSecondDialog.dismiss();
                    exitLiveSecondDialog = null;
                }
                doRequestCloseLive();


            }
        });
        exitLiveSecondDialog.show();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(ShowPop showPop) {
        if (android.os.Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
            if (showPop.isShow) {
                rl_load.setVisibility(View.VISIBLE);
            } else {
                rl_load.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            //在此处返回false,所以会继续传播该事件
            if (liveShareDialog != null && liveShareDialog.getVisibility() == View.VISIBLE) {
                liveShareDialog.setVisibility(View.GONE);
                return true;
            } else {
                try {
//                    destory();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            exit();
                        }
                    });

                } catch (Exception e) {

                }

                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    public void doRequestCloseLive() {
//        requestParams.put("room_id",roomid);
        sendRequest(getRequestUrl(UrlConstants.CLOSE_LIVE), null);
    }
}
