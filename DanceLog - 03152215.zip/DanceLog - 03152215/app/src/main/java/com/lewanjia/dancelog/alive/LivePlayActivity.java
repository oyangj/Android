package com.lewanjia.dancelog.alive;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.vodplayer.media.AliyunLocalSource;
import com.aliyun.vodplayer.media.IAliyunVodPlayer;
import com.example.playerlibrary.AlivcLiveRoom.AliyunScreenMode;
import com.example.playerlibrary.AlivcLiveRoom.AliyunVodPlayerView;
import com.example.playerlibrary.AlivcLiveRoom.DensityUtil;
import com.example.playerlibrary.AlivcLiveRoom.ErrorInfo;
import com.example.playerlibrary.AlivcLiveRoom.PlayParameter;
import com.example.playerlibrary.AlivcLiveRoom.ScreenUtils;
import com.facebook.drawee.view.SimpleDraweeView;
import com.gyf.immersionbar.ImmersionBar;
import com.lewanjia.dancelog.MyApplication;
import com.lewanjia.dancelog.R;
import com.lewanjia.dancelog.event.PayRefreshEvent;
import com.lewanjia.dancelog.event.PaySuccessEvent;
import com.lewanjia.dancelog.event.ShowPop;
import com.lewanjia.dancelog.http.UrlConstants;
import com.lewanjia.dancelog.model.BasePayInfo;
import com.lewanjia.dancelog.model.QuestionListBean;
import com.lewanjia.dancelog.model.QuestionListInfo;
import com.lewanjia.dancelog.model.RoomUserInfo;
import com.lewanjia.dancelog.model.SubscribeNumInfo;
import com.lewanjia.dancelog.ui.activity.PayActivity;
import com.lewanjia.dancelog.ui.activity.WebFullActivity;
import com.lewanjia.dancelog.ui.views.ExitLiveDialog;
import com.lewanjia.dancelog.ui.views.LiveExitDialog;
import com.lewanjia.dancelog.ui.views.LivePayDialog;
import com.lewanjia.dancelog.ui.views.PaySuccessDialog;
import com.lewanjia.dancelog.ui.views.popuwindow.QuestionListPopupWindow;
import com.lewanjia.dancelog.utils.Constants;
import com.lewanjia.dancelog.utils.DataConstants;
import com.lewanjia.dancelog.utils.JsonUtils;
import com.lewanjia.dancelog.utils.LogUtils;
import com.lewanjia.dancelog.utils.LoginUtils;
import com.lewanjia.dancelog.utils.PreferencesUtils;
import com.loopj.android.http.RequestParams;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


/**
 * @author herozii
 * @version 1.0
 * @date 2020/2/13
 */
public class LivePlayActivity extends BaseLiveActivity {

    static AliyunVodPlayerView mAliyunVodPlayerView;
    private String DEFAULT_URL = "rtmp://liveclient.xvfin.com/dancelog/test?auth_key=1581305354-0-0-b8f6d6697b1498fec3718bf12b6bcd0e";
    private ErrorInfo currentError = ErrorInfo.Normal;
    private SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss.SS");
    private List<String> logStrs = new ArrayList<>();
    String url;
    Timer timer;
    LivePayDialog livePayDialog;
    BasePayInfo basePayInfo;
    boolean ispay;

    SimpleDraweeView simpleDraweeView;
    TextView tvTop;
    TextView tvBottom;
    String name;
    String headImg;
    String pushUser;
    int userid;
    int numSub;
    boolean isMirror = false;
    Timer timerNum;
    static boolean mute;
    private RelativeLayout rl_load;
    private static boolean canRetry = false;
    private static boolean isFirstError = true;
    private static long errorTime;
    String live_status;
    long appoint_time;
    ImageView look;
    ImageView question;
    ImageView iv_more;
    TextView tv_more;
    RelativeLayout rl_bottom;
    public static void start(Context context, String id, String url, BasePayInfo basePayInfo, String pic,
                             String name, String head, boolean ispay, int num, String pushUser, int userid, int price,String live_status ,long appoint_time ) {
        Intent intent = new Intent(context, LivePlayActivity.class);
        intent.putExtra("room_id", id);
        intent.putExtra("url", url);
        intent.putExtra("data", (Serializable) basePayInfo);
        intent.putExtra("pic", pic);
        intent.putExtra("name", name);
        intent.putExtra("head", head);
        intent.putExtra("ispay", ispay);
        intent.putExtra("num", num);
        intent.putExtra("pushUser", pushUser);
        intent.putExtra("userid", userid);
        intent.putExtra("price", price);
        intent.putExtra("live_status", live_status);
        intent.putExtra("appoint_time",appoint_time);
        context.startActivity(intent);
    }


    public void timer() {
        try {
            timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            show();
                        }
                    });
                }
            }, 60000);
        } catch (Exception e) {

        }
    }

    public void timerNum() {
        try {
            timerNum = new Timer();
            timerNum.schedule(new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            userid = getIntent().getIntExtra("userid", 0);
                            RequestParams requestParams = new RequestParams();
                            requestParams.put("uid", userid);
                            sendRequest(getRequestUrl(UrlConstants.GET_USER_SUSCRIBE_NUM), requestParams);
                        }
                    });
                }
            }, 0, 20000);
        } catch (Exception e) {

        }
    }

    public void show() {
        livePayDialog = new LivePayDialog(LivePlayActivity.this, R.style.livedialog);
        livePayDialog.createDialog();
        livePayDialog.setOnClick(new LivePayDialog.OnClick() {
            @Override
            public void onClick(View view, boolean isSure) {
                PreferencesUtils.putBoolean(LivePlayActivity.this, roomid, true);

                if (isSure) {
                    toPay();
                } else {
                    finish();
                }
            }
        });
        livePayDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                PreferencesUtils.putBoolean(LivePlayActivity.this, roomid, true);

                if (!ispay) {
                    finish();
                }
            }
        });
        if (mAliyunVodPlayerView != null) {
            mAliyunVodPlayerView.onPause();
        }

//        mAliyunVodPlayerView.setMuteMote(true);
        livePayDialog.show();

    }

    public void toPay() {
        List<BasePayInfo> list = new ArrayList<>();
        if (basePayInfo != null) {
            list.add(basePayInfo);
            PayActivity.startForResult(LivePlayActivity.this, list, PayActivity.TYPE_LIVE);
        }

    }

    public void paySuccess() {
        PaySuccessDialog paySuccessDialog = new PaySuccessDialog(LivePlayActivity.this, R.style.mydialog);
        paySuccessDialog.createDialog();
        paySuccessDialog.show();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(PaySuccessEvent paySuccessEvent) {
        if (paySuccessEvent != null && paySuccessEvent.success) {
            paySuccess();
            EventBus.getDefault().post(new PayRefreshEvent(true));
        }
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_play);
        roomid = getIntent().getStringExtra("room_id");
        url = getIntent().getStringExtra("url");
        basePayInfo = (BasePayInfo) getIntent().getSerializableExtra("data");
        pushUser = getIntent().getStringExtra("pushUser");
        ispay = getIntent().getBooleanExtra("ispay", false);
        live_status = getIntent().getStringExtra("live_status");
        appoint_time = getIntent().getLongExtra("appoint_time",-1);

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        init();
        rl_load = findViewById(R.id.rl_load);
        look = findViewById(R.id.look);
        question= findViewById(R.id.question);
        iv_more = findViewById(R.id.iv_more);
        rl_bottom = findViewById(R.id.rl_bottom);
        setListener();
        ImmersionBar.with(this).fullScreen(true).transparentBar().init();
        initAliyunPlayerView();
        if (!TextUtils.isEmpty(roomid)) {
            if (basePayInfo != null) {
                LogUtils.i("hrx", "-basePayInfo-" + basePayInfo.toString());
                if (!TextUtils.isEmpty(basePayInfo.price)) {
                    int price = Integer.valueOf(basePayInfo.price);
                    if (price <= 0)
                        return;
                }
            }

            if (!ispay) {
                if (PreferencesUtils.getBoolean(LivePlayActivity.this, roomid)) {
                    show();
                } else {
                    timer();
                }
            }
        }

    }
    public void setListener(){
        look.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //请求问题列表
                doRequestQuestionList();
            }
        });
        question.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //弹出对话框,编辑框显示“提问”

                setVisible();
                if(inputDialog!=null){
                    if(inputDialog.mEditText!=null)
                        inputDialog.mEditText.setText(R.string.question);
                }
            }
        });
        iv_more.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //弹出对话框,编辑框显示“提问”
                if(rl_bottom.getVisibility()==View.VISIBLE || tv_more.getVisibility()==View.VISIBLE){
                    rl_bottom.setVisibility(View.GONE);
                    tv_more.setVisibility(View.GONE);
                    iv_more.setBackgroundResource(R.mipmap.icon_open);
                }else{
                    rl_bottom.setVisibility(View.VISIBLE);
                    tv_more.setVisibility(View.VISIBLE);
                    iv_more.setBackgroundResource(R.mipmap.icon_slice);
                }

            }
        });
    }

    int num = 0;

    @Override
    public void onRequestSuccess(String url, String result, Object... extra) {
        super.onRequestSuccess(url, result, extra);
        if (getRequestUrl(UrlConstants.GET_ROOM_USER).equals(url)) {
            String type = (String) extra[0].toString();
            if (type.equals(TYPE_OFFLINE)) {
                RoomUserInfo roomUserInfo = JsonUtils.toBean(result, RoomUserInfo.class);
                if (DataConstants.OFFLINE_CHAT_LIST != null
                        && DataConstants.OFFLINE_CHAT_LIST.size() > 0) {
                    DataConstants.OFFLINE_CHAT_LIST.clear();
                }
                if (roomUserInfo != null) {
                    if (roomUserInfo.getData() != null) {
                        if (roomUserInfo.getData().getList() != null) {
                            offLineNum = roomUserInfo.getData().getList().getTotal_count();
                            if (roomUserInfo.getData().getList().getUsers() != null &&
                                    roomUserInfo.getData().getList().getUsers().size() > 0) {

                                DataConstants.OFFLINE_CHAT_LIST.addAll(roomUserInfo.getData().getList().getUsers());
                            }
                        }
                    }
                }
//                if (roomid != null && DataConstants.getLiveChatInfoOutLive(roomid) != null) {
//                    DataConstants.OFFLINE_CHAT_LIST.addAll(DataConstants.getLiveChatInfoOutLive(roomid));
//                }

                num++;

            }
            if (type.equals(TYPE_ONLINE)) {
                RoomUserInfo roomUserInfo = JsonUtils.toBean(result, RoomUserInfo.class);
                if (DataConstants.ONLINE_CHAT_LIST != null
                        && DataConstants.ONLINE_CHAT_LIST.size() > 0) {
                    DataConstants.ONLINE_CHAT_LIST.clear();
                }
                //先获取网络的
                if (roomUserInfo != null) {
                    if (roomUserInfo.getData() != null) {
                        if (roomUserInfo.getData().getList() != null) {
                            onLineNum = roomUserInfo.getData().getList().getTotal_count();
                            if (roomUserInfo.getData().getList().getUsers() != null &&
                                    roomUserInfo.getData().getList().getUsers().size() > 0) {

                                DataConstants.ONLINE_CHAT_LIST.addAll(roomUserInfo.getData().getList().getUsers());
                            }
                        }
                    }
                }
                num++;

//                if (roomid != null && DataConstants.getLiveChatInfoAtLive(roomid) != null) {
//                    DataConstants.ONLINE_CHAT_LIST.addAll(DataConstants.getLiveChatInfoAtLive(roomid));
//                }
            }
            if (num == 2) {
                showDialog();
                num = 0;
            }
        } else if (getRequestUrl(UrlConstants.SAVE_VISIT_LIVE_RECORD).equals(url)) {
//            doRequestRoomNum(TYPE_OFFLINE);
//            doRequestRoomNum(TYPE_ONLINE);
        } else if (getRequestUrl(UrlConstants.GET_USER_SUSCRIBE_NUM).equals(url)) {
            SubscribeNumInfo subscribeNumInfo = JsonUtils.toBean(result, SubscribeNumInfo.class);
            if (subscribeNumInfo != null) {
                if (subscribeNumInfo.getData() != null) {
                    tvBottom.setText(subscribeNumInfo.getData().getSubscribe_num() + "人");
                }
            }
        }else if(getRequestUrl(UrlConstants.GET_QUESTION_LIST).equals(url)){
            QuestionListInfo questionListInfo = JsonUtils.toBean(result, QuestionListInfo.class);
            if(questionListInfo != null){
                if(questionListInfo.getResult() == 200){
                    QuestionListInfo.DataBean dataBean =  questionListInfo.getData();
                   int totalNum = dataBean.getTotal_count();
                   List<QuestionListBean> list = dataBean.getList();

                    QuestionListPopupWindow window = new QuestionListPopupWindow(this,800,1000,list);
                    View root = LayoutInflater.from(this).inflate(R.layout.activity_live_play,null);
                    window.showAtLocation(root,Gravity.BOTTOM,0,0);
                }
            }

        }
    }

    @Override
    public void onRequestFailure(String url, int errorCode, String error, String result, Object... extra) {
        super.onRequestFailure(url, errorCode, error, result, extra);
    }

    private void initAliyunPlayerView() {
        simpleDraweeView = findViewById(R.id.iv);
        tvTop = findViewById(R.id.tv_top);
        tvBottom = findViewById(R.id.tv_bottom);
        name = getIntent().getStringExtra("name");
        headImg = getIntent().getStringExtra("head");
        numSub = getIntent().getIntExtra("num", 0);
        if (!TextUtils.isEmpty(name)) {
            tvTop.setText(name);
        }
        if (!TextUtils.isEmpty(headImg)) {
            simpleDraweeView.setImageURI(Uri.parse(headImg));
        }

        tvBottom.setText(numSub + "人");
        mAliyunVodPlayerView = findViewById(R.id.play_view);
        mAliyunVodPlayerView.initVideoView(true);
        mAliyunVodPlayerView.setKeepScreenOn(true);
        if (TextUtils.isEmpty(url)) {
            return;
        }
        PlayParameter.PLAY_PARAM_URL = url;
//        String sdDir = Environment.getExternalStorageDirectory().getAbsolutePath() + "/test_save_cache";
//        mAliyunVodPlayerView.setPlayingCache(false, sdDir, 60 * 60 /*时长, s */, 300 /*大小，MB*/);
        mAliyunVodPlayerView.setTheme(AliyunVodPlayerView.Theme.Blue);
//        mAliyunVodPlayerView.setCirclePlay(true);//循环
        mAliyunVodPlayerView.setAutoPlay(true);
        mAliyunVodPlayerView.setControlBarCanShow(false);
        mAliyunVodPlayerView.setTitleBarCanShow(false);
//        mAliyunVodPlayerView.setCoverResource(R.drawable.cover_fm);
        mAliyunVodPlayerView.setOnPreparedListener(new MyPrepareListener(this));
//        mAliyunVodPlayerView.setNetConnectedListener(new MyNetConnectedListener(this));
        mAliyunVodPlayerView.setOnCompletionListener(new MyCompletionListener(this));
        mAliyunVodPlayerView.setOnFirstFrameStartListener(new MyFrameInfoListener(this));
        mAliyunVodPlayerView.setOnChangeQualityListener(new MyChangeQualityListener(this));
        mAliyunVodPlayerView.setOnStoppedListener(new MyStoppedListener(this));
        mAliyunVodPlayerView.setmOnPlayerViewClickListener(new MyPlayViewClickListener());
        mAliyunVodPlayerView.setOrientationChangeListener(new MyOrientationChangeListener(this));
        mAliyunVodPlayerView.setOnUrlTimeExpiredListener(new MyOnUrlTimeExpiredListener(this));
        mAliyunVodPlayerView.setOnErrorListener(new MyErrorListener(this));

//        mAliyunVodPlayerView.setOnErrorListener(new IAliyunVodPlayer.OnErrorListener() {
//            @Override
//            public void onError(int i, int i1, String s) {
//                LogUtils.i("hrx", "--<<onError" + s);
//                mAliyunVodPlayerView.rePlay();
//            }
//        });
        mAliyunVodPlayerView.setOnTimeExpiredErrorListener(new IAliyunVodPlayer.OnTimeExpiredErrorListener() {
            @Override
            public void onTimeExpiredError() {
                LogUtils.i("hrx", "--<<onTimeExpiredError");
                mAliyunVodPlayerView.rePlay();
            }
        });

        mAliyunVodPlayerView.enableNativeLog();
        mAliyunVodPlayerView.changeScreenMode2();
        AliyunLocalSource.AliyunLocalSourceBuilder alsb = new AliyunLocalSource.AliyunLocalSourceBuilder();
        alsb.setSource(PlayParameter.PLAY_PARAM_URL);
        Uri uri = Uri.parse(PlayParameter.PLAY_PARAM_URL);
        if ("rtmp".equals(uri.getScheme())) {
            alsb.setTitle("");
        }
        AliyunLocalSource localSource = alsb.build();
        mAliyunVodPlayerView.setLiveSource(localSource);
        mAliyunVodPlayerView.start();

        findViewById(R.id.ll_mirror).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mAliyunVodPlayerView != null) {
                    isMirror = !isMirror;
                    if (isMirror) {
                        mAliyunVodPlayerView.setRenderMirrorMode(IAliyunVodPlayer.VideoMirrorMode.VIDEO_MIRROR_MODE_HORIZONTAL);
                    } else {
                        mAliyunVodPlayerView.setRenderMirrorMode(IAliyunVodPlayer.VideoMirrorMode.VIDEO_MIRROR_MODE_NONE);
                    }

                    LogUtils.i("hrx", "--isMirror--" + isMirror);
                }
            }
        });
        findViewById(R.id.iv_mirror).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mAliyunVodPlayerView != null) {
                    isMirror = !isMirror;
                    if (isMirror) {
                        mAliyunVodPlayerView.setRenderMirrorMode(IAliyunVodPlayer.VideoMirrorMode.VIDEO_MIRROR_MODE_HORIZONTAL);
                    } else {
                        mAliyunVodPlayerView.setRenderMirrorMode(IAliyunVodPlayer.VideoMirrorMode.VIDEO_MIRROR_MODE_NONE);
                    }

                    LogUtils.i("hrx", "--isMirror--" + isMirror);
                }
            }
        });
        findViewById(R.id.rl_head).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!TextUtils.isEmpty(LoginUtils.getToken(LivePlayActivity.this)) &&
                        !TextUtils.isEmpty(pushUser)) {

                    String token = LoginUtils.getToken(LivePlayActivity.this);
                    if (!TextUtils.isEmpty(PreferencesUtils.getString(MyApplication.getContext(), Constants.Shareprefrence.H5_URL))) {
                        String url = PreferencesUtils.getString(MyApplication.getContext(), Constants.Shareprefrence.H5_URL)
                                + UrlConstants.HOME_HEAD + pushUser + UrlConstants.OTHER_HOME + token;
                        startActivity(WebFullActivity.actionToView(LivePlayActivity.this,
                                url, "", true));
                    }

                }
            }
        });
        findViewById(R.id.iv).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!TextUtils.isEmpty(LoginUtils.getToken(LivePlayActivity.this)) &&
                        !TextUtils.isEmpty(pushUser)) {

                    String token = LoginUtils.getToken(LivePlayActivity.this);
                    if (!TextUtils.isEmpty(PreferencesUtils.getString(MyApplication.getContext(), Constants.Shareprefrence.H5_URL))) {
                        String url = PreferencesUtils.getString(MyApplication.getContext(), Constants.Shareprefrence.H5_URL)
                                + UrlConstants.HOME_HEAD + pushUser + UrlConstants.OTHER_HOME + token;
                        startActivity(WebFullActivity.actionToView(LivePlayActivity.this,
                                url, "", true));
                    }

                }
            }
        });
        findViewById(R.id.iv).setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                //弹出对话框 @yonghu

                setVisible();

                return false;
            }
        });
        timerNum();
    }

    @Override
    protected void onPause() {
        super.onPause();
//        ScreenRotateUtil.getInstance(this).stop();
        if (mAliyunVodPlayerView != null) {
            mAliyunVodPlayerView.onPause();
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        ScreenRotateUtil.getInstance(this).stop();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
        onDestroyView();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        ScreenRotateUtil.getInstance(this).start(this);
        LogUtils.i("hrx", "---" + mAliyunVodPlayerView.getPlayerState().toString() +
                mAliyunVodPlayerView.getPlayerState().name());
        if (mAliyunVodPlayerView != null) {
            mAliyunVodPlayerView.onResume();
        }

//        doRequestRoomNum(TYPE_OFFLINE);
//        doRequestRoomNum(TYPE_ONLINE);
    }

    private static class MyErrorListener implements IAliyunVodPlayer.OnErrorListener {
        WeakReference<LivePlayActivity> weakReference;

        public MyErrorListener(LivePlayActivity activity) {
            weakReference = new WeakReference<LivePlayActivity>(activity);
        }


        @Override
        public void onError(int i, int i1, String s) {
            LogUtils.i("hrx", "-onError-" + i + "-i1-" + i1 + "-s-" + s);
            if (isFirstError) {
                errorTime = System.currentTimeMillis();
            }
            isFirstError = false;
            LivePlayActivity activity = weakReference.get();
            if (activity != null) {
                if (System.currentTimeMillis() - errorTime > (60 * 1000)) {
                    activity.onStopped(false);
                } else {
                    activity.onStopped(true);
                }
            }
        }
    }

    //
    private static class MyOnUrlTimeExpiredListener implements IAliyunVodPlayer.OnUrlTimeExpiredListener {
        WeakReference<LivePlayActivity> weakReference;

        public MyOnUrlTimeExpiredListener(LivePlayActivity activity) {
            weakReference = new WeakReference<LivePlayActivity>(activity);
        }

        @Override
        public void onUrlTimeExpired(String s, String s1) {
            LogUtils.i("hrx", "--<<onUrlTimeExpired");
            LivePlayActivity activity = weakReference.get();
            activity.onUrlTimeExpired(s, s1);
        }
    }

    private void onUrlTimeExpired(String oldVid, String oldQuality) {
        //requestVidSts();
//        AliyunVidSts vidSts = VidStsUtil.getVidSts(oldVid);
//        PlayParameter.PLAY_PARAM_VID = vidSts.getVid();
//        PlayParameter.PLAY_PARAM_AK_SECRE = vidSts.getAkSceret();
//        PlayParameter.PLAY_PARAM_AK_ID = vidSts.getAcId();
//        PlayParameter.PLAY_PARAM_SCU_TOKEN = vidSts.getSecurityToken();

    }

    //
    private static class MyOrientationChangeListener implements AliyunVodPlayerView.OnOrientationChangeListener {

        private final WeakReference<LivePlayActivity> weakReference;

        public MyOrientationChangeListener(LivePlayActivity activity) {
            weakReference = new WeakReference<>(activity);
        }

        @Override
        public void orientationChange(boolean from, AliyunScreenMode currentMode) {
            LivePlayActivity activity = weakReference.get();
            LogUtils.i("hrx", "--<<orientationChange");
            if (currentMode == AliyunScreenMode.Full) { //全屏切换设置高度
                activity.setScreen(true);
            } else if (currentMode == AliyunScreenMode.Small) {
                activity.setScreen(false);
            }
//            activity.hideDownloadDialog(from, currentMode);
//            activity.hideShowMoreDialog(from, currentMode);
        }
    }

    private void setScreen(boolean isAll) {
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        if (isAll) {
            params.height = ScreenUtils.getHeight(this);
            mAliyunVodPlayerView.setLayoutParams(params);
//            mAlivcChatRoomView.setVisibility(View.GONE);
//            iv_close.setVisibility(View.GONE);
        } else {
            params.height = DensityUtil.dp2px(this, 200);
            params.gravity = Gravity.CENTER;
            mAliyunVodPlayerView.setLayoutParams(params);
//            mAlivcChatRoomView.setVisibility(View.VISIBLE);
//            iv_close.setVisibility(View.VISIBLE);
        }
    }

    private void hideShowMoreDialog(boolean from, AliyunScreenMode currentMode) {
//        if (showMoreDialog != null) {
//            if (currentMode == AliyunScreenMode.Small) {
//                showMoreDialog.dismiss();
//                currentScreenMode = currentMode;
//            }
//        }
    }

    private void hideDownloadDialog(boolean from, AliyunScreenMode currentMode) {

//        if (downloadDialog != null) {
//            if (currentScreenMode != currentMode) {
//                downloadDialog.dismiss();
//                currentScreenMode = currentMode;
//            }
//        }
    }

    //
    private class MyPlayViewClickListener implements AliyunVodPlayerView.OnPlayerViewClickListener {
        @Override
        public void onClick(AliyunScreenMode screenMode, AliyunVodPlayerView.PlayViewType viewType) {
            // 如果当前的Type是Download, 就显示Download对话框
//            if (viewType == AliyunVodPlayerView.PlayViewType.Download) {
//                showAddDownloadView(screenMode);
//            }
            LogUtils.i("hrx", "--<<onClick");
        }
    }

    //
    private static class MyStoppedListener implements IAliyunVodPlayer.OnStoppedListener {

        private WeakReference<LivePlayActivity> activityWeakReference;

        public MyStoppedListener(LivePlayActivity skinActivity) {
            activityWeakReference = new WeakReference<LivePlayActivity>(skinActivity);
        }

        @Override
        public void onStopped() {
            LogUtils.i("hrx", "--<<onStopped");
            LivePlayActivity activity = activityWeakReference.get();
            if (activity != null) {
                activity.onStopped(true);
            }
        }
    }

    private void onStopped(boolean b) {
//        Toast.makeText(LivePlayActivity.this.getApplicationContext(), R.string.log_play_stopped,
//                Toast.LENGTH_SHORT).show();
        //-onError-4008-i1-4008-s-视频加载超时，请检查网络状况
        if (mAliyunVodPlayerView != null) {
            if (mAliyunVodPlayerView.getPlayerState() != null &&
                    mAliyunVodPlayerView.getPlayerState() == IAliyunVodPlayer.PlayerState.Stopped) {
                showOutDialog();
            } else if (mAliyunVodPlayerView.getPlayerState() == IAliyunVodPlayer.PlayerState.Error) {
                if (b) {
                    if (mAliyunVodPlayerView.isPlaying()) {

                    } else {
                        mAliyunVodPlayerView.reTry();
                    }
                } else {
                    showOutDialog();
                }
            }
        }

    }

    private void showOutDialog() {
        LogUtils.i("hrx", "--getPlayerState--" + mAliyunVodPlayerView.getPlayerState().toString() +
                mAliyunVodPlayerView.getPlayerState().name());
        LiveExitDialog exitDialog = new LiveExitDialog(LivePlayActivity.this);
        exitDialog.createDialog();
        exitDialog.setOnClick(new LiveExitDialog.OnClick() {
            @Override
            public void onClick(View view, boolean isSure) {
                finish();
            }
        });
        exitDialog.show();
    }

    //
    private static class MyChangeQualityListener implements IAliyunVodPlayer.OnChangeQualityListener {

        private WeakReference<LivePlayActivity> activityWeakReference;

        public MyChangeQualityListener(LivePlayActivity skinActivity) {
            activityWeakReference = new WeakReference<LivePlayActivity>(skinActivity);
        }

        @Override
        public void onChangeQualitySuccess(String finalQuality) {
            LogUtils.i("hrx", "--<<onChangeQualitySuccess");
            LivePlayActivity activity = activityWeakReference.get();
            if (activity != null) {
                activity.onChangeQualitySuccess(finalQuality);
            }
        }

        @Override
        public void onChangeQualityFail(int code, String msg) {
            LogUtils.i("hrx", "--<<onChangeQualityFail");
            LivePlayActivity activity = activityWeakReference.get();
            if (activity != null) {
                activity.onChangeQualityFail(code, msg);
            }
        }
    }

    private void onChangeQualitySuccess(String finalQuality) {
        logStrs.add(format.format(new Date()) + getString(R.string.log_change_quality_success));
        Toast.makeText(LivePlayActivity.this.getApplicationContext(),
                getString(R.string.log_change_quality_success), Toast.LENGTH_SHORT).show();
    }

    void onChangeQualityFail(int code, String msg) {
        logStrs.add(format.format(new Date()) + getString(R.string.log_change_quality_fail) + " : " + msg);
        Toast.makeText(LivePlayActivity.this.getApplicationContext(),
                getString(R.string.log_change_quality_fail), Toast.LENGTH_SHORT).show();
    }

    //
    private static class MyFrameInfoListener implements IAliyunVodPlayer.OnFirstFrameStartListener {

        private WeakReference<LivePlayActivity> activityWeakReference;

        public MyFrameInfoListener(LivePlayActivity skinActivity) {
            activityWeakReference = new WeakReference<LivePlayActivity>(skinActivity);
        }

        @Override
        public void onFirstFrameStart() {
            LogUtils.i("hrx", "--<<onFirstFrameStart--");
            LivePlayActivity activity = activityWeakReference.get();
            if (activity != null) {
                activity.onFirstFrameStart();
                canRetry = false;
            }
        }
    }

    private void onFirstFrameStart() {
        Map<String, String> debugInfo = mAliyunVodPlayerView.getAllDebugInfo();
        long createPts = 0;
        if (debugInfo.get("create_player") != null) {
            String time = debugInfo.get("create_player");
            createPts = (long) Double.parseDouble(time);
            logStrs.add(format.format(new Date(createPts)) + getString(R.string.log_player_create_success));
        }
        if (debugInfo.get("open-url") != null) {
            String time = debugInfo.get("open-url");
            long openPts = (long) Double.parseDouble(time) + createPts;
            logStrs.add(format.format(new Date(openPts)) + getString(R.string.log_open_url_success));
        }
        if (debugInfo.get("find-stream") != null) {
            String time = debugInfo.get("find-stream");
            long findPts = (long) Double.parseDouble(time) + createPts;
            logStrs.add(format.format(new Date(findPts)) + getString(R.string.log_request_stream_success));
        }
        if (debugInfo.get("open-stream") != null) {
            String time = debugInfo.get("open-stream");
            long openPts = (long) Double.parseDouble(time) + createPts;
            logStrs.add(format.format(new Date(openPts)) + getString(R.string.log_start_open_stream));
        }
        logStrs.add(format.format(new Date()) + getString(R.string.log_first_frame_played));
        for (String log : logStrs) {
            LogUtils.i("hrx", "--<<onFirstFrameStart" + log);
        }
    }

    //
    private static class MyCompletionListener implements IAliyunVodPlayer.OnCompletionListener {

        private WeakReference<LivePlayActivity> activityWeakReference;

        public MyCompletionListener(LivePlayActivity skinActivity) {
            activityWeakReference = new WeakReference<LivePlayActivity>(skinActivity);
        }

        @Override
        public void onCompletion() {
            LogUtils.i("hrx", "--<<onCompletion");

        }
    }

    private void onCompletion() {
//        logStrs.add(format.format(new Date()) + getString(R.string.log_play_completion));
//        for (String log : logStrs) {
//            tvLogs.append(log + "\n");
//        }
//        Toast.makeText(MainActivity.this.getApplicationContext(), R.string.toast_play_compleion,
//                Toast.LENGTH_SHORT).show();
//
//        // 当前视频播放结束, 播放下一个视频
//        onNext();

    }

    private void onNext() {
//        if (currentError == ErrorInfo.UnConnectInternet) {
//            // 此处需要判断网络和播放类型
//            // 网络资源, 播放完自动波下一个, 无网状态提示ErrorTipsView
//            // 本地资源, 播放完需要重播, 显示Replay, 此处不需要处理
//            if ("vidsts".equals(PlayParameter.PLAY_PARAM_TYPE)) {
//                mAliyunVodPlayerView.showErrorTipView(4014, -1, "当前网络不可用");
//            }
//            return;
//        }
//
//        currentVideoPosition++;
//        if (currentVideoPosition >= alivcVideoInfos.size() - 1) {
//            //列表循环播放，如发现播放完成了从列表的第一个开始重新播放
//            currentVideoPosition = 0;
//        }
//
//        AlivcVideoInfo.Video video = alivcVideoInfos.get(currentVideoPosition);
//        if (video != null) {
//            changePlayVidSource(video.getVideoId(), video.getTitle());
//        }
    }

    /**
     * 判断是否有网络的监听
     */
    private class MyNetConnectedListener implements AliyunVodPlayerView.NetConnectedListener {
        WeakReference<LivePlayActivity> weakReference;

        public MyNetConnectedListener(LivePlayActivity activity) {
            weakReference = new WeakReference<>(activity);
        }

        @Override
        public void onReNetConnected(boolean isReconnect) {
            LivePlayActivity activity = weakReference.get();
            activity.onReNetConnected(isReconnect);
            LogUtils.i("hrx", "--<<onReNetConnected");
        }

        @Override
        public void onNetUnConnected() {
            LivePlayActivity activity = weakReference.get();
            activity.onNetUnConnected();
            LogUtils.i("hrx", "--<<onNetUnConnected");
        }
    }

    private void onNetUnConnected() {
        currentError = ErrorInfo.UnConnectInternet;
//        if (aliyunDownloadMediaInfoList != null && aliyunDownloadMediaInfoList.size() > 0) {
//            downloadManager.stopDownloadMedias(aliyunDownloadMediaInfoList);
//        }
    }

    private void onReNetConnected(boolean isReconnect) {
        if (isReconnect) {
//            if (aliyunDownloadMediaInfoList != null && aliyunDownloadMediaInfoList.size() > 0) {
//                int unCompleteDownload = 0;
//                for (AliyunDownloadMediaInfo info : aliyunDownloadMediaInfoList) {
//                    //downloadManager.startDownloadMedia(info);
//                    if (info.getStatus() == AliyunDownloadMediaInfo.Status.Stop) {
//
//                        unCompleteDownload++;
//                    }
//                }
//
//                if (unCompleteDownload > 0) {
//                    Toast.makeText(this, "网络恢复, 请手动开启下载任务...", Toast.LENGTH_SHORT).show();
//                }
//            }
//            VidStsUtil.getVidSts(PlayParameter.PLAY_PARAM_VID, new MyStsListener(this));
        }
    }

    //
    private static class MyPrepareListener implements IAliyunVodPlayer.OnPreparedListener {

        private WeakReference<LivePlayActivity> activityWeakReference;

        public MyPrepareListener(LivePlayActivity skinActivity) {
            activityWeakReference = new WeakReference<LivePlayActivity>(skinActivity);
        }

        @Override
        public void onPrepared() {
            LivePlayActivity activity = activityWeakReference.get();
            if (activity != null) {
                activity.onPrepared();
            }
            LogUtils.i("hrx", "--<<onPrepared");
        }
    }

    private void onPrepared() {

//        Toast.makeText(LivePlayActivity.this.getApplicationContext(), R.string.toast_prepare_success,
//                Toast.LENGTH_SHORT).show();
//        if (mAliyunVodPlayerView != null){
//            if (livePayDialog != null && livePayDialog.isShowing()){
//                mAliyunVodPlayerView.setMuteMote(true);
//            }
//
//        }
//        if (!ispay) {
//            if (mAliyunVodPlayerView != null) {
//                mAliyunVodPlayerView.onPause();
//            }
//        }
    }

    //横竖屏切换
    public void toggleFullScreen(Context context) {
        if (getScreenOrientation(context) == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {//设为横屏
            isScreenFull = false;
            ((Activity) context).setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            //如果是固定全屏，那么直接设置view的布局，宽高
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) mAliyunVodPlayerView.getLayoutParams();
            params.height = ScreenUtils.getWidth(context) * 9 / 16;
            params.width = ViewGroup.LayoutParams.MATCH_PARENT;
            params.topMargin = DensityUtil.dp2px(context, 100);
        } else {
            isScreenFull = true;
            ((Activity) context).setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//设为竖屏
            //如果是固定全屏，那么直接设置view的布局，宽高
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) mAliyunVodPlayerView.getLayoutParams();
            params.height = ViewGroup.LayoutParams.MATCH_PARENT;
            params.width = ViewGroup.LayoutParams.MATCH_PARENT;
            params.topMargin = 0;
        }
    }

    /**
     * 获取界面方向
     */
    public int getScreenOrientation(Context context) {
        int rotation = ((Activity) context).getWindowManager().getDefaultDisplay().getRotation();
        DisplayMetrics dm = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        int orientation;
        // if the device's natural orientation is portrait:
        if ((rotation == Surface.ROTATION_0
                || rotation == Surface.ROTATION_180) && height > width ||
                (rotation == Surface.ROTATION_90
                        || rotation == Surface.ROTATION_270) && width > height) {
            switch (rotation) {
                case Surface.ROTATION_0:
                    orientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                    break;
                case Surface.ROTATION_90:
                    orientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
                    break;
                case Surface.ROTATION_180:
                    orientation =
                            ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT;
                    break;
                case Surface.ROTATION_270:
                    orientation =
                            ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE;
                    break;
                default:
                    orientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                    break;
            }
        }
        // if the device's natural orientation is landscape or if the device
        // is square:
        else {
            switch (rotation) {
                case Surface.ROTATION_0:
                    orientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
                    break;
                case Surface.ROTATION_90:
                    orientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                    break;
                case Surface.ROTATION_180:
                    orientation =
                            ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE;
                    break;
                case Surface.ROTATION_270:
                    orientation =
                            ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT;
                    break;
                default:
                    orientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
                    break;
            }
        }

        return orientation;
    }

    //是否全屏
    private boolean isScreenFull = false;

    //退出弹窗
    ExitLiveDialog exitLiveDialog;

    @Override
    public void exit() {
        exitLiveDialog = new ExitLiveDialog(LivePlayActivity.this, R.style.mydialog);
        exitLiveDialog.createDialog();
        exitLiveDialog.setOnClick(new ExitLiveDialog.OnClick() {
            @Override
            public void onClick(View view, boolean isSure) {
                if (isSure) {

//                    onDestroyView();
                }
            }

            @Override
            public void onSure(View view) {
                finish();
            }
        });
        exitLiveDialog.show();
    }

    public void onDestroyView() {
        if (mAliyunVodPlayerView != null) {
            mAliyunVodPlayerView.onDestroy();
        }
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
        if (timerNum != null) {
            timerNum.cancel();
            timerNum = null;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            //在此处返回false,所以会继续传播该事件
            if (livePayDialog != null && livePayDialog.isShowing()) {
                finish();
                return true;
            }
            if (liveShareDialog != null && liveShareDialog.getVisibility() == View.VISIBLE) {
                liveShareDialog.setVisibility(View.GONE);
                return true;
            } else {
                exit();
            }
        }
        return super.onKeyDown(keyCode, event);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == PayActivity.TYPE_RESULT) {
            try {
                boolean isPay = data.getBooleanExtra("isPay", false);
//                mAliyunVodPlayerView.setMuteMote(!isPay);
                if (!isPay) {

                    show();
                } else {
                }
            } catch (Exception e) {

            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(ShowPop showPop) {
        if (android.os.Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
            if (showPop.isShow) {
                rl_load.setVisibility(View.VISIBLE);
            } else {
                rl_load.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void rePlay() {
        super.rePlay();
        mAliyunVodPlayerView.rePlay();
    }

    @Override
    public void stopPlay() {
        super.stopPlay();
        canRetry = true;
    }
}
