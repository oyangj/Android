package com.lewanjia.dancelog.base;

import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.support.annotation.LayoutRes;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.githang.statusbar.StatusBarCompat;
import com.gyf.immersionbar.ImmersionBar;
import com.lewanjia.dancelog.Config;
import com.lewanjia.dancelog.MyApplication;
import com.lewanjia.dancelog.R;
import com.lewanjia.dancelog.http.HttpUtils;
import com.lewanjia.dancelog.http.ResponseListener;
import com.lewanjia.dancelog.ui.music.play.PlayService;
import com.lewanjia.dancelog.utils.DialogUtils;
import com.lewanjia.dancelog.utils.LogUtils;
import com.lewanjia.dancelog.utils.Utils;
import com.lewanjia.dancelog.views.EmptyLayout;
import com.lewanjia.dancelog.views.recyclerview.DividerItemDecoration;
import com.lewanjia.dancelog.views.recyclerview.EndlessRecyclerOnScrollListener;
import com.lewanjia.dancelog.views.recyclerview.HeaderAndFooterRecyclerViewAdapter;
import com.lewanjia.dancelog.views.recyclerview.LoadingFooter;
import com.lewanjia.dancelog.views.recyclerview.RecyclerViewStateUtils;
import com.lewanjia.dancelog.views.recyclerview.RecyclerViewUtils;
import com.lewanjia.dancelog.views.refreshLayout.RefreshLayout;
import com.loopj.android.http.RequestParams;
import com.umeng.analytics.MobclickAgent;

import in.srain.cube.views.ptr.PtrDefaultHandler;
import in.srain.cube.views.ptr.PtrFrameLayout;

/**
 * Created by admin on 2017/10/13.
 */

public class BasePageActivity extends AppCompatActivity implements Toolbar.OnMenuItemClickListener {

    public static final int REQUESTCODE_CAMERA = 11111;
    public static final int REQUESTCODE_ALBUM = 22222;
    public static final int REQUESTCODE_CROP = 55555;
    public static final int REQUEST_CODE_CAMERA_PERMISSIONS = 33333;
    public static final int REQUEST_CODE_ALBUM_PERMISSIONS = 44444;
    public static final int REQUEST_CODE_COMPRESS = 555555;

    protected static final int PAGE_FIRST = 1;
    protected static final int PAGE_SIZE_DEFAULT = 10;

    protected int currentPage = PAGE_FIRST;
    protected int totalPage = 1;

    protected int total = 0;

    private RelativeLayout mContentContainer;
    private Toolbar toolbar;
    private TextView titleTv;
    protected ProgressDialog progressDialog;

    protected Handler handler;
    protected PlayService playService;
    private ServiceConnection serviceConnection;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("hrx", "-->" + this.getClass().getSimpleName());
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        handler = new Handler(Looper.getMainLooper());
        bindService();
        Utils.hideBottomUIMenu(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
    }

    private void bindService() {
        Intent intent = new Intent();
        intent.setClass(this, PlayService.class);
        serviceConnection = new PlayServiceConnection();
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    private class PlayServiceConnection implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            playService = ((PlayService.PlayBinder) service).getService();
            onServiceBound();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.e(getClass().getSimpleName(), "service disconnected");
        }
    }

    protected void onServiceBound() {
    }

    protected int getFrameLayoutId() {
        return R.layout.content_frame_with_toolbar;
    }

    protected boolean showTitleBar() {
        return true;
    }

    @Override
    public void setTitle(CharSequence title) {
        super.setTitle("");
        if (titleTv != null) {
            titleTv.setText(title);
        }
    }

    @Override
    public void setTitle(int titleId) {
        setTitle("");
        if (titleId != 0) {
            titleTv.setText(titleId);
        }
    }

    public Toolbar getToolbar() {
        return toolbar;
    }

    @Override
    public void setContentView(@LayoutRes int layoutResID) {
        int frameLayoutId = getFrameLayoutId();
        if (frameLayoutId == 0 || !showTitleBar()) {
            super.setContentView(layoutResID);
        } else {
            super.setContentView(getFrameLayoutId());

            findViews();
            View view = LayoutInflater.from(this).inflate(layoutResID, null);
            addViewToRoot(view);
        }

        StatusBarCompat.setStatusBarColor(this, MyApplication.getContext().getResources().getColor(R.color.status_color));
    }

    @Override
    public void setContentView(View view) {
        super.setContentView(view);
        int frameLayoutId = getFrameLayoutId();
        if (frameLayoutId == 0 || !showTitleBar()) {
            super.setContentView(view);
        } else {
            super.setContentView(getFrameLayoutId());

            findViews();

            addViewToRoot(view);
        }

    }

    private void addViewToRoot(View view) {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        params.addRule(RelativeLayout.BELOW, R.id.toolbar);
        mContentContainer.addView(view, params);
    }

    private void findViews() {
        mContentContainer = (RelativeLayout) findViewById(R.id.frame_content);
        initTitleViews();
    }

    private void initTitleViews() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        titleTv = (TextView) findViewById(R.id.tv_title);

        if (toolbar != null) {
            if (getMenuResId() != 0) {
                toolbar.inflateMenu(getMenuResId());
                toolbar.setOnMenuItemClickListener(this);
            }
            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onBackPressed();
                }
            });
        }
    }

    public int getMenuResId() {
        return 0;
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        return false;
    }

    protected void sendRequest(String url, RequestParams params, Object... extra) {
        HttpUtils.sendRequest(this, HttpUtils.HttpMethod.POST, url, params, responseListener, extra);
    }

    protected void sendRequest(String url, RequestParams params, String dialogMsg, Object... extra) {
        if (!TextUtils.isEmpty(dialogMsg)) {
            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
            progressDialog = DialogUtils.progress(this, dialogMsg);
        }
        sendRequest(url, params, extra);
    }

    ResponseListener responseListener = new ResponseListener() {
        @Override
        public void onSuccess(String url, String result, Object... extra) {
            dismissProgressDialog();
            onRequestSuccess(url, result, extra);
        }

        @Override
        public void onFailure(String url, int errorCode, String error, String result, Object... extra) {
            dismissProgressDialog();
            onRequestFailure(url, errorCode, error, result, extra);
        }

        @Override
        public void onFinish(String url, Object... extra) {
            onRequestFinish(url, extra);
        }

        @Override
        public void onProgress(String url, long bytesWritten, long totalSize, Object... extra) {
            onRequestProgress(url, bytesWritten, totalSize, extra);
        }
    };

    /**
     * 网络请求成功回调
     */
    public void onRequestSuccess(String url, String result, Object... extra) {

    }

    /**
     * 网络请求失败回调
     */
    public void onRequestFailure(String url, int errorCode, String error, String result, Object... extra) {
    }

    /**
     * 网络请求完成回调
     */
    public void onRequestFinish(String url, Object... extra) {

    }

    public void onRequestProgress(String url, long bytesWritten, long totalSize, Object... extra) {

    }

    protected void dismissProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    @Override
    protected void onDestroy() {
        dismissProgressDialog();
        super.onDestroy();

        if (serviceConnection != null) {
            unbindService(serviceConnection);
        }
    }

    public String getRequestUrl(String suffix) {
        return MyApplication.getInstance().getServerUrl() + suffix;
    }

    public String getImgRequestUrl(String suffix) {
        return MyApplication.getInstance().getImgUrl() + suffix;
    }


    //分页
    public static final int LIST_SUCCESS = 0;
    public static final int LIST_NO_DATA = 1;
    public static final int LIST_ERROR = 2;

    protected RefreshLayout refreshLayout;
    protected RecyclerView recyclerView;
    private HeaderAndFooterRecyclerViewAdapter headerAndFooterRecyclerViewAdapter;
    protected EmptyLayout emptyLayout;

    public void setView(RecyclerView recyclerView, RefreshLayout refreshLayout,
                         EmptyLayout emptyLayout) {
        this.refreshLayout = refreshLayout;
        this.recyclerView = recyclerView;
        this.emptyLayout = emptyLayout;
        if (recyclerView == null) {
            throw new RuntimeException(
                    "Your content must have a RecyclerView whose id attribute is " +
                            "'R.id.recycler'");
        }

        recyclerView.setLayoutManager(getLayoutManager());
        recyclerView.setItemAnimator(getItemAnimator());
        if (getItemDecoration() != null) {
            recyclerView.addItemDecoration(getItemDecoration());
        }
        recyclerView.addOnScrollListener(onScrollListener);

        refreshLayout = (RefreshLayout) findViewById(R.id.layout_refresh);
        if (refreshLayout != null) {
            refreshLayout.setPtrHandler(refreshListener);
        }

        emptyLayout = (EmptyLayout) findViewById(R.id.layout_empty);
        if (emptyLayout != null) {
            emptyLayout.setVisibility(View.GONE);
            emptyLayout.setOnRefreshListener(new EmptyLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    performRefresh();
                }
            });
        }
    }

    public void setListAdapter(RecyclerView.Adapter adapter) {
        headerAndFooterRecyclerViewAdapter = new HeaderAndFooterRecyclerViewAdapter(adapter);
        recyclerView.setAdapter(headerAndFooterRecyclerViewAdapter);
    }

    public void addHeaderView(View header) {
        if (headerAndFooterRecyclerViewAdapter == null) {
            throw new RuntimeException("headerAndFooterRecyclerViewAdapter is null , please setListAdapter()");
        }
        RecyclerViewUtils.setHeaderView(recyclerView, header);
    }

    protected RecyclerView.ItemDecoration getItemDecoration() {
        return new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST);
    }

    protected RecyclerView.ItemAnimator getItemAnimator() {
        return new DefaultItemAnimator();
    }

    protected int getPageSize() {
        return PAGE_SIZE_DEFAULT;
    }

    protected void onPullDownRefresh() {
        currentPage = PAGE_FIRST;
        total = 0;
        if (emptyLayout != null) {
            emptyLayout.setVisibility(View.GONE);
        }
    }

    protected void onLoadMore() {
        int totalPage = getPageSize() > 0 ? (int) Math.ceil(total / (float) getPageSize()) : 0;
        RecyclerViewStateUtils.setFooterViewState(this, recyclerView, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.Loading, null);
        //正在加载更多的时候，不允许下拉刷新
        if (refreshLayout != null) {
            refreshLayout.setEnabled(false);
        }
    }
    public RequestParams getLoadMoreRequestParams() {
        RequestParams params = new RequestParams();
        params.put("page", currentPage);
        params.put("page_size", getPageSize());
        return params;
    }

    PtrDefaultHandler refreshListener = new PtrDefaultHandler() {
        @Override
        public void onRefreshBegin(PtrFrameLayout frame) {
            frame.postDelayed(new Runnable() {
                @Override
                public void run() {
                    onPullDownRefresh();
                }
            }, Config.PULL_DOWN_REFRESH_DELAY);
        }
    };

    EndlessRecyclerOnScrollListener onScrollListener = new EndlessRecyclerOnScrollListener() {
        @Override
        public void onLoadNextPage(View view) {
            RecyclerView.Adapter outerAdapter = recyclerView.getAdapter();
            if (outerAdapter == null || !(outerAdapter instanceof HeaderAndFooterRecyclerViewAdapter)) {
                return;
            }

            LoadingFooter.State state = RecyclerViewStateUtils.getFooterViewState(recyclerView);
            LogUtils.i("state=======>" + state);
            if ((refreshLayout != null && refreshLayout.isRefreshing())
                    || LoadingFooter.State.Loading.Loading == state
                    || LoadingFooter.State.TheEnd == state)
                return;
            onLoadMore();
        }

        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            onRecyclerScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            onRecyclerScrolled(recyclerView, dx, dy);
        }
    };

    public void onRecyclerScrolled(RecyclerView recyclerView, int dx, int dy) {
        //recyclerview onScrolled()
    }

    public void onRecyclerScrollStateChanged(RecyclerView recyclerView, int newState) {
    }

    public void performRefresh() {
        LoadingFooter.State status = RecyclerViewStateUtils.getFooterViewState(recyclerView);
        if (status == LoadingFooter.State.Loading) {
            return;
        }
//        RecyclerViewStateUtils.setFooterViewState(this, recyclerViewInflate, currentPage,
//                getPageSize() > 0 ? (int) Math.ceil(total / (float) getPageSize()) : 0, PAGE_FIRST,
//                LoadingFooter.State.Normal, "", null);
        if (refreshLayout != null) {
            refreshLayout.post(new Runnable() {
                @Override
                public void run() {
//                    refreshLayoutInflate.autoRefresh(true, (int) Config.PULL_DOWN_REFRESH_DELAY);
                    refreshLayout.autoRefresh(true);
                }
            });
        }
    }

    public void completeRefresh() {
        if (refreshLayout != null) {
            refreshLayout.setEnabled(true);
            if (refreshLayout.isRefreshing()) {
                refreshLayout.refreshComplete();
            }
        }
    }

    /**
     * 完成加载
     *
     * @param state LIST_SUCCESS，LIST_NO_DATA，LIST_ERROR
     * @param msg   加载错误描述
     */
    public void completeLoad(int total, int state, CharSequence msg, View.OnClickListener footerListener) {
        this.total = total;
        if (currentPage == PAGE_FIRST || (currentPage != PAGE_FIRST && total > 0)) {
            totalPage = getPageSize() > 0 ? (int) Math.ceil(total / (float) getPageSize()) : 0;
        }
        LogUtils.i("curPage:" + currentPage);
        LogUtils.i("totalPage:" + totalPage);
        switch (state) {
            case LIST_SUCCESS:
                completeRefresh();
                if (emptyLayout != null) {
                    emptyLayout.setVisibility(View.GONE);
                }

                if (currentPage >= totalPage) { //最后一页
                    RecyclerViewStateUtils.setFooterViewState(this, recyclerView, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.TheEnd, msg, footerListener);
                } else {
                    RecyclerViewStateUtils.setFooterViewState(this, recyclerView, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.Normal, msg, footerListener);
                    currentPage += 1;
                }
                break;

            case LIST_NO_DATA:
                completeRefresh();
                RecyclerViewStateUtils.setFooterViewState(this, recyclerView, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.TheEnd, msg, footerListener);
                if (currentPage == PAGE_FIRST) {//第一页
                    //显示错误页面
                    if (emptyLayout != null) {
                        emptyLayout.setVisibility(View.VISIBLE);
                        emptyLayout.showError(TextUtils.isEmpty(msg) ? Utils.getSafeString(R.string.no_data) : msg);
                    }
                }
                break;

            case LIST_ERROR:
                completeRefresh();
                if (currentPage == PAGE_FIRST) { //第一页
                    RecyclerViewStateUtils.setFooterViewState(this, recyclerView, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.Normal, msg, footerListener);
                    //显示错误页面
                    if (emptyLayout != null) {
                        emptyLayout.setVisibility(View.VISIBLE);
                        emptyLayout.showError(TextUtils.isEmpty(msg) ? Utils.getSafeString(R.string.get_data_failed) : msg);
                    }
                } else {
                    RecyclerViewStateUtils.setFooterViewState(this, recyclerView, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.Error, msg, footerListener == null ? errorListener : footerListener);
                }
                break;
        }

    }

    public void completeLoad(int total, int state, CharSequence msg) {
        completeLoad(total, state, msg, null);
    }

    /**
     * 不需要分页的
     *
     * @param state
     * @param msg
     */
    public void completeLoad(int state, CharSequence msg) {
        completeLoad(0, state, msg, null);
    }

    View.OnClickListener errorListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            onLoadMore();
        }
    };

    protected RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(this);
    }
}
