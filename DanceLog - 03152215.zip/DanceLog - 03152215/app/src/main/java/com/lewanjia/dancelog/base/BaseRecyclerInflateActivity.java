package com.lewanjia.dancelog.base;

import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;

import com.lewanjia.dancelog.Config;
import com.lewanjia.dancelog.R;
import com.lewanjia.dancelog.utils.LogUtils;
import com.lewanjia.dancelog.utils.Utils;
import com.lewanjia.dancelog.views.EmptyLayout;
import com.lewanjia.dancelog.views.recyclerview.DividerItemDecoration;
import com.lewanjia.dancelog.views.recyclerview.EndlessRecyclerOnScrollListener;
import com.lewanjia.dancelog.views.recyclerview.HeaderAndFooterRecyclerViewAdapter;
import com.lewanjia.dancelog.views.recyclerview.LoadingFooter;
import com.lewanjia.dancelog.views.recyclerview.RecyclerViewStateUtils;
import com.lewanjia.dancelog.views.recyclerview.RecyclerViewUtils;
import com.lewanjia.dancelog.views.refreshLayout.RefreshLayout;
import com.loopj.android.http.RequestParams;

import in.srain.cube.views.ptr.PtrDefaultHandler;
import in.srain.cube.views.ptr.PtrFrameLayout;

/**
 * 用于Inflate布局使用
 * 需要调用findViews()
 * @author herozii
 * @version 1.0
 * @date 2019/12/26
 */
public abstract class BaseRecyclerInflateActivity extends BaseActivity {

    public static final int LIST_SUCCESS = 0;
    public static final int LIST_NO_DATA = 1;
    public static final int LIST_ERROR = 2;

    protected RefreshLayout refreshLayoutInflate;
    protected RecyclerView recyclerViewInflate;
    private HeaderAndFooterRecyclerViewAdapter headerAndFooterRecyclerViewAdapterInflate;
    protected EmptyLayout emptyLayoutInflate;



    public void findViews(View view) {
        recyclerViewInflate = (RecyclerView) view.findViewById(R.id.recycler);
        if (recyclerViewInflate == null) {
            throw new RuntimeException(
                    "Your content must have a RecyclerView whose id attribute is " +
                            "'R.id.recycler'");
        }

        recyclerViewInflate.setLayoutManager(getLayoutManager());
        recyclerViewInflate.setItemAnimator(getItemAnimator());
        if (getItemDecoration() != null) {
            recyclerViewInflate.addItemDecoration(getItemDecoration());
        }
        recyclerViewInflate.addOnScrollListener(onScrollListener);

        refreshLayoutInflate = (RefreshLayout) view.findViewById(R.id.layout_refresh);
        if (refreshLayoutInflate != null) {
            refreshLayoutInflate.setPtrHandler(refreshListener);
        }

        emptyLayoutInflate = (EmptyLayout) view.findViewById(R.id.layout_empty);
        if (emptyLayoutInflate != null) {
            emptyLayoutInflate.setVisibility(View.GONE);
            emptyLayoutInflate.setOnRefreshListener(new EmptyLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    performRefresh();
                }
            });
        }

    }

    public void setListAdapter(RecyclerView.Adapter adapter) {
        headerAndFooterRecyclerViewAdapterInflate = new HeaderAndFooterRecyclerViewAdapter(adapter);
        recyclerViewInflate.setAdapter(headerAndFooterRecyclerViewAdapterInflate);
    }

    public void addHeaderView(View header) {
        if (headerAndFooterRecyclerViewAdapterInflate == null) {
            throw new RuntimeException("headerAndFooterRecyclerViewAdapterInflate is null , please setListAdapter()");
        }
//        header.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT));
//        headerAndFooterRecyclerViewAdapterInflate.addHeaderView(header);
        RecyclerViewUtils.setHeaderView(recyclerViewInflate, header);
    }

    protected RecyclerView.LayoutManager getLayoutManager() {
        return new LinearLayoutManager(this);
    }

    protected RecyclerView.ItemDecoration getItemDecoration() {
        return new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST);
    }

    protected RecyclerView.ItemAnimator getItemAnimator() {
        return new DefaultItemAnimator();
    }

    protected int getPageSize() {
        return PAGE_SIZE_DEFAULT;
    }

    protected void onPullDownRefresh() {
        currentPage = PAGE_FIRST;
        total = 0;
        if (emptyLayoutInflate != null) {
            emptyLayoutInflate.setVisibility(View.GONE);
        }
    }
    public RequestParams getLoadMoreRequestParams() {
        RequestParams params = new RequestParams();
        params.put("page", currentPage);
        params.put("page_size", getPageSize());
        return params;
    }

    protected void onLoadMore() {
        int totalPage = getPageSize() > 0 ? (int) Math.ceil(total / (float) getPageSize()) : 0;
        RecyclerViewStateUtils.setFooterViewState(this, recyclerViewInflate, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.Loading, null);
        //正在加载更多的时候，不允许下拉刷新
        if (refreshLayoutInflate != null) {
            refreshLayoutInflate.setEnabled(false);
        }
    }


    PtrDefaultHandler refreshListener = new PtrDefaultHandler() {
        @Override
        public void onRefreshBegin(PtrFrameLayout frame) {
            frame.postDelayed(new Runnable() {
                @Override
                public void run() {
                    onPullDownRefresh();
                }
            }, Config.PULL_DOWN_REFRESH_DELAY);
        }
    };

    EndlessRecyclerOnScrollListener onScrollListener = new EndlessRecyclerOnScrollListener() {
        @Override
        public void onLoadNextPage(View view) {
            RecyclerView.Adapter outerAdapter = recyclerViewInflate.getAdapter();
            if (outerAdapter == null || !(outerAdapter instanceof HeaderAndFooterRecyclerViewAdapter)) {
                return;
            }

            LoadingFooter.State state = RecyclerViewStateUtils.getFooterViewState(recyclerViewInflate);
            LogUtils.i("state=======>" + state);
            if ((refreshLayoutInflate != null && refreshLayoutInflate.isRefreshing())
                    || LoadingFooter.State.Loading.Loading == state
                    || LoadingFooter.State.TheEnd == state)
                return;

            onLoadMore();

//            RecyclerView.Adapter outerAdapter = recyclerViewInflate.getAdapter();
//            if (outerAdapter == null || !(outerAdapter instanceof HeaderAndFooterRecyclerViewAdapter)) {
//                return;
//            }
//            if ((refreshLayoutInflate != null && refreshLayoutInflate.isRefreshing())
//                    || (LoadingFooter.State.TheEnd == RecyclerViewStateUtils.getFooterViewState(recyclerViewInflate))
//                    || (LoadingFooter.State.Loading == RecyclerViewStateUtils.getFooterViewState(recyclerViewInflate))) {
//                return;
//            }
//            super.onLoadNextPage(view);
//            onLoadMore();
        }

        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            onRecyclerScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            onRecyclerScrolled(recyclerView, dx, dy);
        }
    };

    public void onRecyclerScrolled(RecyclerView recyclerView, int dx, int dy) {
        //recyclerview onScrolled()
    }

    public void onRecyclerScrollStateChanged(RecyclerView recyclerView, int newState) {
    }

    public void performRefresh() {
        LoadingFooter.State status = RecyclerViewStateUtils.getFooterViewState(recyclerViewInflate);
        if (status == LoadingFooter.State.Loading) {
            return;
        }
//        RecyclerViewStateUtils.setFooterViewState(this, recyclerViewInflate, currentPage,
//                getPageSize() > 0 ? (int) Math.ceil(total / (float) getPageSize()) : 0, PAGE_FIRST,
//                LoadingFooter.State.Normal, "", null);
        if (refreshLayoutInflate != null) {
            refreshLayoutInflate.post(new Runnable() {
                @Override
                public void run() {
//                    refreshLayoutInflate.autoRefresh(true, (int) Config.PULL_DOWN_REFRESH_DELAY);
                    refreshLayoutInflate.autoRefresh(true);
                }
            });
        }
    }

    public void completeRefresh() {
        if (refreshLayoutInflate != null) {
            refreshLayoutInflate.setEnabled(true);
            if (refreshLayoutInflate.isRefreshing()) {
                refreshLayoutInflate.refreshComplete();
            }
        }
    }

    /**
     * 完成加载
     *
     * @param state LIST_SUCCESS，LIST_NO_DATA，LIST_ERROR
     * @param msg   加载错误描述
     */
    public void completeLoad(int total, int state, CharSequence msg, View.OnClickListener footerListener) {
        this.total = total;
        if (currentPage == PAGE_FIRST || (currentPage != PAGE_FIRST && total > 0)) {
            totalPage = getPageSize() > 0 ? (int) Math.ceil(total / (float) getPageSize()) : 0;
        }
        LogUtils.i("curPage:" + currentPage);
        LogUtils.i("totalPage:" + totalPage);
        switch (state) {
            case LIST_SUCCESS:
                completeRefresh();
                if (emptyLayoutInflate != null) {
                    emptyLayoutInflate.setVisibility(View.GONE);
                }

                if (currentPage >= totalPage) { //最后一页
                    RecyclerViewStateUtils.setFooterViewState(this, recyclerViewInflate, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.TheEnd, msg, footerListener);
                } else {
                    RecyclerViewStateUtils.setFooterViewState(this, recyclerViewInflate, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.Normal, msg, footerListener);
                    currentPage += 1;
                }
                break;

            case LIST_NO_DATA:
                completeRefresh();
                RecyclerViewStateUtils.setFooterViewState(this, recyclerViewInflate, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.TheEnd, msg, footerListener);
                if (currentPage == PAGE_FIRST) {//第一页
                    //显示错误页面
                    if (emptyLayoutInflate != null) {
                        emptyLayoutInflate.setVisibility(View.VISIBLE);
                        emptyLayoutInflate.showError(TextUtils.isEmpty(msg) ? Utils.getSafeString(R.string.no_data) : msg);
                    }
                }
                break;

            case LIST_ERROR:
                completeRefresh();
                if (currentPage == PAGE_FIRST) { //第一页
                    RecyclerViewStateUtils.setFooterViewState(this, recyclerViewInflate, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.Normal, msg, footerListener);
                    //显示错误页面
                    if (emptyLayoutInflate != null) {
                        emptyLayoutInflate.setVisibility(View.VISIBLE);
                        emptyLayoutInflate.showError(TextUtils.isEmpty(msg) ? Utils.getSafeString(R.string.get_data_failed) : msg);
                    }
                } else {
                    RecyclerViewStateUtils.setFooterViewState(this, recyclerViewInflate, currentPage, totalPage, PAGE_FIRST, LoadingFooter.State.Error, msg, footerListener == null ? errorListener : footerListener);
                }
                break;
        }

    }

    public void completeLoad(int total, int state, CharSequence msg) {
        completeLoad(total, state, msg, null);
    }

    /**
     * 不需要分页的
     *
     * @param state
     * @param msg
     */
    public void completeLoad(int state, CharSequence msg) {
        completeLoad(0, state, msg, null);
    }

    View.OnClickListener errorListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            onLoadMore();
        }
    };

    public RequestParams getRequestParams() {
        RequestParams params = new RequestParams();
        params.put("pageno", currentPage);
        params.put("pagesize", getPageSize());
        return params;
    }

    @Override
    public void onRequestFailure(String url, int errorCode, String error, String result, Object... extra) {
        super.onRequestFailure(url, errorCode, error, result, extra);
//        loginExpired(errorCode);
        completeLoad(0, LIST_ERROR, Utils.getRespError(errorCode, error, Utils.getSafeString(R.string.get_data_failed)));
    }

}
