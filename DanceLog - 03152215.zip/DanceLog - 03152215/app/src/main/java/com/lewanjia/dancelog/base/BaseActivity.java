package com.lewanjia.dancelog.base;

import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.support.annotation.LayoutRes;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.githang.statusbar.StatusBarCompat;
import com.lewanjia.dancelog.MyApplication;
import com.lewanjia.dancelog.R;
import com.lewanjia.dancelog.http.HttpUtils;
import com.lewanjia.dancelog.http.ResponseListener;
import com.lewanjia.dancelog.ui.music.play.PlayService;
import com.lewanjia.dancelog.utils.DialogUtils;
import com.lewanjia.dancelog.utils.Utils;
import com.loopj.android.http.RequestParams;
import com.umeng.analytics.MobclickAgent;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by admin on 2017/10/13.
 */

public class BaseActivity extends AppCompatActivity implements Toolbar.OnMenuItemClickListener {

    public static final int REQUESTCODE_CAMERA = 11111;
    public static final int REQUESTCODE_ALBUM = 22222;
    public static final int REQUESTCODE_CROP = 55555;
    public static final int REQUEST_CODE_CAMERA_PERMISSIONS = 33333;
    public static final int REQUEST_CODE_ALBUM_PERMISSIONS = 44444;
    public static final int REQUEST_CODE_COMPRESS = 555555;

    protected static final int PAGE_FIRST = 1;
    protected static final int PAGE_SIZE_DEFAULT = 10;

    protected int currentPage = PAGE_FIRST;
    protected int totalPage = 1;

    protected int total = 0;

    private RelativeLayout mContentContainer;
    private Toolbar toolbar;
    private TextView titleTv;
    protected ProgressDialog progressDialog;

    protected Handler handler;
    protected PlayService playService;
    private ServiceConnection serviceConnection;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("hrx","-->" + this.getClass().getSimpleName());
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        handler = new Handler(Looper.getMainLooper());
        bindService();
        Utils.hideBottomUIMenu(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
    }

    private void bindService() {
        Intent intent = new Intent();
        intent.setClass(this, PlayService.class);
        serviceConnection = new PlayServiceConnection();
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    private class PlayServiceConnection implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            playService = ((PlayService.PlayBinder) service).getService();
            onServiceBound();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.e(getClass().getSimpleName(), "service disconnected");
        }
    }

    protected void onServiceBound() {
    }

    protected int getFrameLayoutId() {
        return R.layout.content_frame_with_toolbar;
    }

    protected boolean showTitleBar() {
        return true;
    }

    @Override
    public void setTitle(CharSequence title) {
        super.setTitle("");
        if (titleTv != null) {
            titleTv.setText(title);
        }
    }

    @Override
    public void setTitle(int titleId) {
        setTitle("");
        if (titleId != 0) {
            titleTv.setText(titleId);
        }
    }

    public Toolbar getToolbar() {
        return toolbar;
    }

    @Override
    public void setContentView(@LayoutRes int layoutResID) {
        int frameLayoutId = getFrameLayoutId();
        if (frameLayoutId == 0 || !showTitleBar()) {
            super.setContentView(layoutResID);
        } else {
            super.setContentView(getFrameLayoutId());

            findViews();
            View view = LayoutInflater.from(this).inflate(layoutResID, null);
            addViewToRoot(view);
        }

        StatusBarCompat.setStatusBarColor(this, MyApplication.getContext().getResources().getColor(R.color.status_color));
    }

    @Override
    public void setContentView(View view) {
        super.setContentView(view);
        int frameLayoutId = getFrameLayoutId();
        if (frameLayoutId == 0 || !showTitleBar()) {
            super.setContentView(view);
        } else {
            super.setContentView(getFrameLayoutId());

            findViews();

            addViewToRoot(view);
        }

    }

    private void addViewToRoot(View view) {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        params.addRule(RelativeLayout.BELOW, R.id.toolbar);
        mContentContainer.addView(view, params);
    }

    private void findViews() {
        mContentContainer = (RelativeLayout) findViewById(R.id.frame_content);
        initTitleViews();
    }

    private void initTitleViews() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        titleTv = (TextView) findViewById(R.id.tv_title);

        if (toolbar != null) {
            if (getMenuResId() != 0) {
                toolbar.inflateMenu(getMenuResId());
                toolbar.setOnMenuItemClickListener(this);
            }
            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onBackPressed();
                }
            });
        }
    }

    public int getMenuResId() {
        return 0;
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        return false;
    }

    protected void sendRequest(String url, RequestParams params, Object... extra) {
        HttpUtils.sendRequest(this, HttpUtils.HttpMethod.POST, url, params, responseListener, extra);
    }

    protected void sendRequest(String url, RequestParams params, String dialogMsg, Object... extra) {
        if (!TextUtils.isEmpty(dialogMsg)) {
            if (progressDialog != null && progressDialog.isShowing()){
                progressDialog.dismiss();
            }
            progressDialog = DialogUtils.progress(this, dialogMsg);
        }
        sendRequest(url, params, extra);
    }

    ResponseListener responseListener = new ResponseListener() {
        @Override
        public void onSuccess(String url, String result, Object... extra) {
            dismissProgressDialog();
            onRequestSuccess(url, result, extra);
        }

        @Override
        public void onFailure(String url, int errorCode, String error, String result, Object... extra) {
            dismissProgressDialog();
            onRequestFailure(url, errorCode, error, result, extra);
        }

        @Override
        public void onFinish(String url, Object... extra) {
            onRequestFinish(url, extra);
        }

        @Override
        public void onProgress(String url, long bytesWritten, long totalSize, Object... extra) {
            onRequestProgress(url, bytesWritten, totalSize, extra);
        }
    };

    /**
     * 网络请求成功回调
     */
    public void onRequestSuccess(String url, String result, Object... extra) {
        Log.e("bdf", url);
        Log.e("bdf", result);
    }


    /**
     * 网络请求失败回调
     */
    public void onRequestFailure(String url, int errorCode, String error, String result, Object... extra) {
        if (!TextUtils.isEmpty(result))
        Log.e("bdf", result);
    }

    /**
     * 网络请求完成回调
     */
    public void onRequestFinish(String url, Object... extra) {

    }

    public void onRequestProgress(String url, long bytesWritten, long totalSize, Object... extra) {

    }

    protected void dismissProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    @Override
    protected void onDestroy() {
        dismissProgressDialog();
        super.onDestroy();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
        if (serviceConnection != null) {
            unbindService(serviceConnection);
        }
    }

    public String getRequestUrl(String suffix) {
        return MyApplication.getInstance().getServerUrl() + suffix;
    }

    public String getImgRequestUrl(String suffix) {
        return MyApplication.getInstance().getImgUrl() + suffix;
    }

}
