package com.lewanjia.dancelog.base;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.lewanjia.dancelog.Config;
import com.lewanjia.dancelog.MyApplication;
import com.lewanjia.dancelog.R;
import com.lewanjia.dancelog.http.HttpUtils;
import com.lewanjia.dancelog.http.ResponseListener;
import com.lewanjia.dancelog.model.MenuInfo;
import com.lewanjia.dancelog.ui.views.ListDialog;
import com.lewanjia.dancelog.utils.DeviceUtils;
import com.lewanjia.dancelog.utils.DialogUtils;
import com.lewanjia.dancelog.utils.LogUtils;
import com.lewanjia.dancelog.utils.ToastUtils;
import com.lewanjia.dancelog.utils.Utils;
import com.lewanjia.dancelog.utils.photos.PhotoUtils;
import com.loopj.android.http.RequestParams;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

/**
 * Created by admin on 2017/10/13.
 */

public class BaseFragment extends Fragment implements Toolbar.OnMenuItemClickListener, EasyPermissions.PermissionCallbacks {

    protected static final int PAGE_FIRST = 1;
    protected static final int PAGE_SIZE_DEFAULT = 20;

    protected int currentPage = PAGE_FIRST;
    protected int totalPage = 1;

    protected int total = 0;

    protected Context mContext;

    private RelativeLayout mContentContainer;
    private Toolbar toolbar;
    private TextView titleTv;

    protected ProgressDialog progressDialog;

    public static final int REQUESTCODE_CAMERA = 11111;
    public static final int REQUESTCODE_ALBUM = 22222;
    public static final int REQUEST_CODE_CAMERA_PERMISSIONS = 33333;
    public static final int REQUEST_CODE_ALBUM_PERMISSIONS = 44444;
    public static final int REQUESTCODE_CROP = 55555;

    private String[] permsCamera = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
    private String[] permsAlbum = {Manifest.permission.WRITE_EXTERNAL_STORAGE};

    private ListDialog picDialog;
    private File tempFile;
    protected File tempCropFile;

    protected int getFrameLayoutId() {
        return R.layout.content_frame_with_toolbar;
    }

    protected boolean showTitleBar() {
        return false;
    }

    @Nullable
    @Override
    public final View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mContext = getActivity();
        Log.i("hrx","-->" + this.getClass().getSimpleName());
        if (getFrameLayoutId() != 0 && showTitleBar()) {
            ViewGroup parent = (ViewGroup) inflater.inflate(getFrameLayoutId(), null);
            findViews(parent);
            addViewToRoot(createView(inflater, parent, savedInstanceState));
            return parent;
        }
        return createView(inflater, container, savedInstanceState);
    }

    protected View createView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return null;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initPicDialog();
    }

    public void setTitle(CharSequence title) {
        if (titleTv != null) {
            titleTv.setText(title);
        }
    }

    public void setTitle(int titleId) {
        if (titleId != 0) {
            titleTv.setText(titleId);
        }
    }

    public Toolbar getToolbar() {
        return toolbar;
    }

    private void addViewToRoot(View child) {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        params.addRule(RelativeLayout.BELOW, R.id.toolbar);
        mContentContainer.addView(child, params);
    }

    private void findViews(View view) {
        mContentContainer = (RelativeLayout) view.findViewById(R.id.frame_content);
        toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        titleTv = (TextView) view.findViewById(R.id.tv_title);
        if (toolbar != null) {
            if (getMenuResId() != 0) {
                toolbar.inflateMenu(getMenuResId());
                toolbar.setOnMenuItemClickListener(this);
            }
            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onBackPressed();
                }
            });
        }
    }

    public int getMenuResId() {
        return 0;
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        return false;
    }

    protected void sendRequest(String url, RequestParams params, Object... extra) {
        HttpUtils.sendRequest(mContext, HttpUtils.HttpMethod.POST, url, params, responseListener, extra);
    }

    protected void sendRequest(String url, RequestParams params, String dialogMsg, Object... extra) {
        if (!TextUtils.isEmpty(dialogMsg)) {
            progressDialog = DialogUtils.progress(mContext, dialogMsg);
        }
        sendRequest(url, params, extra);
    }

    ResponseListener responseListener = new ResponseListener() {
        @Override
        public void onSuccess(String url, String result, Object... extra) {
            dismissProgressDialog();
            onRequestSuccess(url, result, extra);
        }

        @Override
        public void onFailure(String url, int errorCode, String error, String result, Object... extra) {
            dismissProgressDialog();
            onRequestFailure(url, errorCode, error, result, extra);
        }

        @Override
        public void onFinish(String url, Object... extra) {
            onRequestFinish(url, extra);
        }

        @Override
        public void onProgress(String url, long bytesWritten, long totalSize, Object... extra) {
            onRequestProgress(url, bytesWritten, totalSize, extra);
        }
    };

    /**
     * 网络请求成功回调
     */
    public void onRequestSuccess(String url, String result, Object... extra) {

    }

    /**
     * 网络请求失败回调
     */
    public void onRequestFailure(String url, int errorCode, String error, String result, Object... extra) {
    }

    /**
     * 网络请求完成回调
     */
    public void onRequestFinish(String url, Object... extra) {

    }

    public void onRequestProgress(String url, long bytesWritten, long totalSize, Object... extra) {

    }

    protected void dismissProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    @Override
    public void onDestroy() {
        dismissProgressDialog();
        super.onDestroy();
    }

    public void onBackPressed() {
        if (getActivity() != null) {
            getActivity().onBackPressed();
        }
    }

    public String getSafeString(int resId) {
        return Utils.getSafeString(resId);
    }

    public String getSafeString(int resId, Object... formatArgs) {
        return Utils.getSafeString(resId, formatArgs);
    }

    public String getRequestUrl(String suffix) {
//        return "http://danceimg.wan888888.com/api/v1/"+suffix;
        return MyApplication.getInstance().getServerUrl() + suffix;
    }

    public String getImgRequestUrl(String suffix) {
        return MyApplication.getInstance().getImgUrl() + suffix;
    }

    public void initPicDialog() {
        picDialog = new ListDialog(mContext);
        List<MenuInfo> data = new ArrayList<>();
        data.add(new MenuInfo("0", getString(R.string.take_photo)));
        data.add(new MenuInfo("1", getString(R.string.album)));
        picDialog.setData(data);
        picDialog.setOnDialogClickListener(new ListDialog.OnDialogClickListener() {
            @Override
            public void onItemClick(Dialog dialog, MenuInfo info) {
                if (info.id.equals("0")) {
                    //拍照
                    requestCameraPermissions();
                } else {
                    //相册
                    requestAlbumPermissions();
                }
            }
        });
    }

    public void showPicDialog() {
        picDialog.show();
    }

    @AfterPermissionGranted(REQUEST_CODE_CAMERA_PERMISSIONS)
    public void requestCameraPermissions() {
        if (EasyPermissions.hasPermissions(mContext, permsCamera)) {
            doCamera();
        } else {
            EasyPermissions.requestPermissions(this, getString(R.string.photographing_authority), REQUEST_CODE_CAMERA_PERMISSIONS, permsCamera);
        }
    }

    @AfterPermissionGranted(REQUEST_CODE_ALBUM_PERMISSIONS)
    public void requestAlbumPermissions() {
        if (EasyPermissions.hasPermissions(mContext, permsAlbum)) {
            PhotoUtils.toAlbum(getActivity(), REQUESTCODE_ALBUM);
        } else {
            EasyPermissions.requestPermissions(this, getString(R.string.open_album_authority), REQUEST_CODE_ALBUM_PERMISSIONS, permsAlbum);
        }
    }

    public void doCamera() {
        File dirFile = new File(Config.PHOTO_PATH);
        if (!dirFile.exists()) {
            dirFile.mkdirs();
        }
        tempFile = new File(dirFile, System.currentTimeMillis() + ".jpg");
        PhotoUtils.toCamera(getActivity(), tempFile, REQUESTCODE_CAMERA);
    }


    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
        LogUtils.w("onPermissionsGranted==>");
//        if (REQUEST_CODE_ALBUM_PERMISSIONS == requestCode) {
//            PhotoUtils.toAlbum(getActivity(), REQUESTCODE_ALBUM);
//        } else if (REQUEST_CODE_CAMERA_PERMISSIONS == requestCode) {
//            doCamera();
//        }
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        if (!EasyPermissions.hasPermissions(mContext, REQUEST_CODE_ALBUM_PERMISSIONS == requestCode ? permsAlbum : permsCamera)) {
            DialogUtils.dialogBuilder(mContext, getString(R.string.apply_permissions),
                    getString(R.string.photo_open_settings, getString(R.string.app_name)),
                    getString(R.string.go_to_set), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            DeviceUtils.startAppSettings(mContext);
                        }
                    }, getString(R.string.cancel), null);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        LogUtils.w("result-Ok:" + resultCode);
        if (REQUESTCODE_CAMERA == requestCode) {
            String imgPath = tempFile.getPath();
            if (!TextUtils.isEmpty(imgPath) && tempFile.length() > 0) {
                //展示图片
                if (getNeedCrop()) {
                    //截图
                    tempCropFile = new File(Config.PHOTO_PATH + Long.toString(System.nanoTime()) + "_cropped.jpg");
                    if (tempCropFile.exists()) {
                        tempCropFile.delete();
                    }
                    PhotoUtils.toCrop(getActivity(), tempFile, tempCropFile, 0, REQUESTCODE_CROP);
                } else {
                    onPhotoCallBack(requestCode, imgPath);
                }
            } else {
                ToastUtils.show(mContext, Utils.getSafeString(R.string.take_photo_fail));
            }
        } else if (REQUESTCODE_ALBUM == requestCode) {
            if (data == null) {
                ToastUtils.show(mContext, Utils.getSafeString(R.string.album_photo_fail));
                return;
            }
            Uri imgUri = data.getData();
            String imgPath = PhotoUtils.uriToPath(mContext, imgUri);
            if (!TextUtils.isEmpty(imgPath)) {
                if (getNeedCrop()) {
                    //截图
                    tempCropFile = new File(Config.PHOTO_PATH + Long.toString(System.nanoTime()) + "_cropped.jpg");
                    if (tempCropFile.exists()) {
                        tempCropFile.delete();
                    }
                    PhotoUtils.toCrop(getActivity(), new File(imgPath), tempCropFile, 0, REQUESTCODE_CROP);
                } else {
                    onPhotoCallBack(requestCode, imgPath);
                }
            } else {
                ToastUtils.show(mContext, Utils.getSafeString(R.string.album_photo_fail));
            }
        } else if (REQUESTCODE_CROP == requestCode) {
            String imgPath = tempCropFile.getPath();
            if (tempFile != null) {
                tempFile.delete();
            }
            if (!TextUtils.isEmpty(imgPath) && tempCropFile.length() > 0) {
                //展示图片
                onPhotoCallBack(requestCode, imgPath);
            } else {
                ToastUtils.show(mContext, Utils.getSafeString(R.string.crop_photo_fail));
            }
        }
    }

    protected void onPhotoCallBack(int requestCode, String imgPath) {

    }

    protected boolean getNeedCrop() {
        return true;
    }
}
