package com.lewanjia.dancelog.base;

import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.android.vlayout.DelegateAdapter;
import com.alibaba.android.vlayout.LayoutHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * @author herozii
 * @version 1.0
 * @date 2019/11/21
 */
public class BaseDelegeteAdapter extends DelegateAdapter.Adapter<BaseViewHolder> {
    private LayoutHelper mLayoutHelper;
    public int mCount = -1;
    private int mLayoutId = -1;
    private Context mContext;
    private int mViewTypeItem = -1;
    public int isVisible = View.VISIBLE;//初始化为不可见
    public int isGONEVisible = View.GONE;//初始化为不可见

    public int isVisible() {
        return isVisible;
    }

    public void setVisible(int visible) {
//        isVisible = visible;
//
//        new Handler().post(new Runnable() {
//            @Override
//            public void run() {
//                // 刷新操作
//                notifyDataSetChanged();
//            }
//        });
    }

    public void setCount(int count){
        this.mCount = count;
        notifyDataSetChanged();
    }

    public void setLayoutHelper(LayoutHelper layoutHelper){
        this.mLayoutHelper = layoutHelper;

    }

    public BaseDelegeteAdapter(Context context) {
        this.mContext = context;
    }


    public BaseDelegeteAdapter(Context context, int layoutId, int viewTypeItem) {
        this.mContext = context;
        this.mLayoutId = layoutId;
        this.mViewTypeItem = viewTypeItem;
    }


    public BaseDelegeteAdapter(Context context, LayoutHelper layoutHelper, int layoutId, int viewTypeItem) {
        this.mContext = context;
        this.mLayoutHelper = layoutHelper;
        this.mLayoutId = layoutId;
        this.mViewTypeItem = viewTypeItem;
    }

    public BaseDelegeteAdapter(Context context, LayoutHelper layoutHelper, int layoutId, int count, int viewTypeItem) {
        this.mContext = context;
        this.mCount = count;
        this.mLayoutHelper = layoutHelper;
        this.mLayoutId = layoutId;
        this.mViewTypeItem = viewTypeItem;
    }

    public void setConstruct(LayoutHelper layoutHelper, int layoutId, int count, int viewTypeItem){
        this.mCount = count;
        this.mLayoutHelper = layoutHelper;
        this.mLayoutId = layoutId;
        this.mViewTypeItem = viewTypeItem;
    }
    @Override
    public LayoutHelper onCreateLayoutHelper() {
        return mLayoutHelper;
    }

    @Override
    public BaseViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == mViewTypeItem) {

            return new BaseViewHolder(LayoutInflater.from(mContext).inflate(mLayoutId, parent, false));

        }
        return null;
//        return new BaseViewHolder(LayoutInflater.from(mContext).inflate(mLayoutId,parent,false));
    }

    @Override
    public void onBindViewHolder(BaseViewHolder holder, int position) {

    }
    /**
     * 必须重写不然会出现滑动不流畅的情况
     */
    @Override
    public int getItemViewType(int position) {
        return mViewTypeItem;
    }
    @Override
    public int getItemCount() {
        return mCount;
    }


    public boolean asserNotNull(List list){
        if (list != null && list.size() > 0){
            return true;
        }else {
            return false;
        }
    }

    public void assertStringNoData(String... parmas){
        for (int i = 0; i < parmas.length; i++) {
            if (TextUtils.isEmpty(parmas[i])){
                return;
            }
        }
    }

    public void assertObjectNoData(Object... parmas){
        for (int i = 0; i < parmas.length; i++) {
            if (parmas[i] == null){
                return;
            }
        }
    }

    private ArrayList<View> mHeaderViews = new ArrayList<>();
    private ArrayList<View> mFooterViews = new ArrayList<>();
    public void addFooterView(View footer) {

        if (footer == null) {
            throw new RuntimeException("footer is null");
        }

        mFooterViews.add(footer);
        this.notifyDataSetChanged();
    }

    /**
     * 返回第一个FoView
     * @return
     */
    public View getFooterView() {
        return  getFooterViewsCount()>0 ? mFooterViews.get(0) : null;
    }

    /**
     * 返回第一个HeaderView
     * @return
     */
    public View getHeaderView() {
        return  getHeaderViewsCount()>0 ? mHeaderViews.get(0) : null;
    }

    public void removeHeaderView(View view) {
        mHeaderViews.remove(view);
        this.notifyDataSetChanged();
    }

    public void removeFooterView(View view) {
        mFooterViews.remove(view);
        this.notifyDataSetChanged();
    }

    public int getHeaderViewsCount() {
        return mHeaderViews.size();
    }

    public int getFooterViewsCount() {
        return mFooterViews.size();
    }

    public boolean isHeader(int position) {
        return getHeaderViewsCount() > 0 && position == 0;
    }

    public boolean isFooter(int position) {
        int lastPosition = getItemCount() - 1;
        return getFooterViewsCount() > 0 && position == lastPosition;
    }

}
