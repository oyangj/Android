package com.lewanjia.dancelog;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.os.Build;
import android.support.multidex.MultiDexApplication;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.sdk.android.oss.common.OSSLog;
import com.aliyun.common.httpfinal.QupaiHttpFinal;
import com.aliyun.sys.AlivcSdkCore;
import com.baidu.aip.FaceEnvironment;
import com.baidu.aip.FaceSDKManager;
import com.baidu.idl.facesdk.FaceTracker;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.imagepipeline.core.ImagePipelineConfig;
import com.lansosdk.videoeditor.LanSoEditor;
import com.lewanjia.dancelog.db.DBManager;
import com.lewanjia.dancelog.event.NetworkConnectChangedReceiver;
import com.lewanjia.dancelog.model.TypeInfo;
import com.lewanjia.dancelog.ui.music.play.AppCache;
import com.lewanjia.dancelog.ui.music.play.PlayService;
import com.lewanjia.dancelog.utils.Constants;
import com.lewanjia.dancelog.utils.ImageLoaderUtils;
import com.lewanjia.dancelog.utils.JsonUtils;
import com.lewanjia.dancelog.utils.PreferencesUtils;
import com.mob.MobSDK;
import com.tencent.smtt.sdk.QbSdk;
import com.umeng.commonsdk.UMConfigure;

import java.util.List;

import cn.jpush.android.api.JPushInterface;
import io.socket.client.Socket;

/**
 * Created by LS on 2018/3/17.
 */

public class MyApplication extends MultiDexApplication {

    private static MyApplication instance;
    private static Context mContext;
    private NetworkConnectChangedReceiver mReceiver;

    /**
     * 接口地址
     */
    private String serverUrl;
    /**
     * 图片地址
     */
    private String imgUrl;

    private String chatUrl;

    /**
     * 服务器时间
     */
    private long serverTime;

    private String userId;
    private String headerUrl;

    private double lat;
    private double lon;

    private List<TypeInfo> dancelLevel;
    private List<TypeInfo> danceType;

    private Socket mSocket;

    public static MyApplication getInstance() {
        if (instance == null) {
            instance = new MyApplication();
        }
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        mContext = getApplicationContext();

        initFresco();

        MobSDK.init(this);

        AppCache.get().init(this);
//        ForegroundObserver.init(this);
        DBManager.get().init(this);

        Intent intent = new Intent(this, PlayService.class);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N_MR1) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }

//        Stetho.initializeWithDefaults(this);

        ImageLoaderUtils.initImageLoader(getApplicationContext());

        UMConfigure.setLogEnabled(Config.DEBUG);
        /**
         注意：如果您已经在AndroidManifest.xml中配置过appkey和channel值，可以调用此版本初始化函数。
         */
        UMConfigure.init(this, UMConfigure.DEVICE_TYPE_PHONE, null);

        //加载so库,并初始化.
        LanSoEditor.initSDK(getApplicationContext(), null);
        initLib();
        initReceive();
        initAlivc();
        initX5();
        JPushInterface.setDebugMode(false);    // 设置开启日志,发布时请关闭日志
        JPushInterface.init(this);            // 初始化 JPush
        // 初始化 JPush
    }

    private void initX5() {
        QbSdk.initX5Environment(this, new QbSdk.PreInitCallback() {
            @Override
            public void onCoreInitFinished() {
                Log.e("bdf", "================>onCoreInitFinished");
            }

            @Override
            public void onViewInitFinished(boolean b) {
                Log.e("bdf", "================>onViewInitFinished");
            }
        });
    }

    public static Context getContext() {
        return mContext;
    }


    private void initAlivc() {
        QupaiHttpFinal.getInstance().initOkHttpFinal();
        AlivcSdkCore.register(getApplicationContext());
        AlivcSdkCore.setLogLevel(AlivcSdkCore.AlivcLogLevel.AlivcLogVerbose);
        OSSLog.enableLog();
    }

    @Override
    public void onTerminate() {
        unregisterReceiver(mReceiver);
        super.onTerminate();
    }


    private void initReceive() {
        mReceiver = new NetworkConnectChangedReceiver();
        IntentFilter mFilter = new IntentFilter();
        mFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(mReceiver, mFilter);
    }


    private void initFresco() {
        ImagePipelineConfig config = ImagePipelineConfig.newBuilder(this)
                .setDownsampleEnabled(true).setResizeAndRotateEnabledForNetwork(true)
                .setBitmapsConfig(Bitmap.Config.RGB_565)
                .build();
        Fresco.initialize(this, config);
    }

    public String getServerUrl() {
        if (TextUtils.isEmpty(serverUrl)) {
            serverUrl = PreferencesUtils.getString(MyApplication.getContext(), Constants.Shareprefrence.SERVER_URL);
        }
        return serverUrl;
    }

    public void setServerUrl(String serverUrl) {
        this.serverUrl = serverUrl;
        PreferencesUtils.putString(MyApplication.getContext(), Constants.Shareprefrence.SERVER_URL, serverUrl);
    }

    public String getImgUrl() {
        if (TextUtils.isEmpty(imgUrl)) {
            imgUrl = PreferencesUtils.getString(MyApplication.getContext(), Constants.Shareprefrence.PIC_URL);
        }
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
        PreferencesUtils.putString(MyApplication.getContext(), Constants.Shareprefrence.PIC_URL, imgUrl);
    }

    public String getChatUrl() {
        if (TextUtils.isEmpty(chatUrl)) {
            chatUrl = PreferencesUtils.getString(MyApplication.getContext(), Constants.Shareprefrence.CHAT_URL);
        }
        return chatUrl;
    }

    public void setChatUrl(String chatUrl) {
        this.chatUrl = chatUrl;
        PreferencesUtils.putString(MyApplication.getContext(), Constants.Shareprefrence.CHAT_URL, chatUrl);
    }

    public long getServerTime() {
        return serverTime;
    }

    public void setServerTime(long serverTime) {
        this.serverTime = serverTime;
    }

    public List<TypeInfo> getDancelLevel() {
        if (dancelLevel == null) {
            String str = PreferencesUtils.getString(MyApplication.getContext(), Constants.Shareprefrence.DANCE_LEVEL);
            dancelLevel = JsonUtils.toList(str, TypeInfo.class);
        }
        return dancelLevel;
    }

    public void setDanceLevel(List<TypeInfo> dancelLevel) {
        this.dancelLevel = dancelLevel;
        PreferencesUtils.putString(MyApplication.getContext(), Constants.Shareprefrence.DANCE_LEVEL, JsonUtils.toJSONString(dancelLevel));
    }

    public List<TypeInfo> getDanceType() {
        if (danceType == null) {
            String str = PreferencesUtils.getString(MyApplication.getContext(), Constants.Shareprefrence.DANCE_TYPE);
            danceType = JsonUtils.toList(str, TypeInfo.class);
        }
        return danceType;
    }

    public void setDanceType(List<TypeInfo> danceType) {
        this.danceType = danceType;
        PreferencesUtils.putString(MyApplication.getContext(), Constants.Shareprefrence.DANCE_TYPE, JsonUtils.toJSONString(danceType));
    }

    public String getUserName() {
        return PreferencesUtils.getString(getContext(), "userName");
    }

    public void setUserName(String userName) {
        PreferencesUtils.putString(getContext(), "userName", userName);
    }

    public String getUserId() {
        if (!TextUtils.isEmpty(userId)) {
            return userId;
        }
        return PreferencesUtils.getString(getContext(), "userId");
    }

    public void setUserId(String userId) {
        this.userId = userId;
        PreferencesUtils.putString(getContext(), "userId", userId);
    }

    public String getHeaderUrl() {
        return PreferencesUtils.getString(getContext(), "headerUrl");
    }

    public void setHeaderUrl(String headerUrl) {
        PreferencesUtils.putString(getContext(), "headerUrl", headerUrl);

    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLon() {
        return lon;
    }

    public void setLon(double lon) {
        this.lon = lon;
    }

    /**
     * 初始化SDK
     */
    private void initLib() {
        // 为了android和ios 区分授权，appId=appname_face_android ,其中appname为申请sdk时的应用名
        // 应用上下文
        // 申请License取得的APPID
        // assets目录下License文件名
//        FaceSDKManager.getInstance().init(this, Config.licenseID, Config.licenseFileName);
//        setFaceConfig();
    }

    private void setFaceConfig() {
        FaceTracker tracker = FaceSDKManager.getInstance().getFaceTracker(this);  //.getFaceConfig();
        // SDK初始化已经设置完默认参数（推荐参数），您也根据实际需求进行数值调整

        // 模糊度范围 (0-1) 推荐小于0.7
        tracker.set_blur_thr(FaceEnvironment.VALUE_BLURNESS);
        // 光照范围 (0-1) 推荐大于40
        tracker.set_illum_thr(FaceEnvironment.VALUE_BRIGHTNESS);
        // 裁剪人脸大小
        tracker.set_cropFaceSize(FaceEnvironment.VALUE_CROP_FACE_SIZE);
        // 人脸yaw,pitch,row 角度，范围（-45，45），推荐-15-15
        tracker.set_eulur_angle_thr(FaceEnvironment.VALUE_HEAD_PITCH, FaceEnvironment.VALUE_HEAD_ROLL,
                FaceEnvironment.VALUE_HEAD_YAW);

        // 最小检测人脸（在图片人脸能够被检测到最小值）80-200， 越小越耗性能，推荐120-200
        tracker.set_min_face_size(FaceEnvironment.VALUE_MIN_FACE_SIZE);
        //
        tracker.set_notFace_thr(FaceEnvironment.VALUE_NOT_FACE_THRESHOLD);
        // 人脸遮挡范围 （0-1） 推荐小于0.5
        tracker.set_occlu_thr(FaceEnvironment.VALUE_OCCLUSION);
        // 是否进行质量检测
        tracker.set_isCheckQuality(true);
        // 是否进行活体校验
        tracker.set_isVerifyLive(false);
    }
}
