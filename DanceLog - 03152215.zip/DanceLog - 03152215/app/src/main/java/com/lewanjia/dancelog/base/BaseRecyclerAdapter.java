package com.lewanjia.dancelog.base;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ys on 2016/6/2.
 */
public abstract class BaseRecyclerAdapter<T extends Object> extends RecyclerView.Adapter {
    public List<T> datas = new ArrayList<>();
    protected Context context;
    protected LayoutInflater layoutInflater;


    public BaseRecyclerAdapter(Context context) {
        this.context = context;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    public void delete(int position) {
        datas.remove(position);
        notifyItemRemoved(position);
    }

    public void add(T elem) {
        datas.add(elem);
        notifyItemInserted(getItemCount());
    }

    public void add(int position, T elem) {
        datas.add(0, elem);
        notifyItemInserted(position);
    }

    public void addAll(List<T> elem) {
        if (elem == null)
            return;
        datas.addAll(elem);
        notifyItemRangeInserted(getItemCount(), elem.size());
    }

    public void replaceAll(List<T> elem) {
        datas.clear();
        if (elem != null) {
            datas.addAll(elem);
        }
        notifyDataSetChanged();
    }

    public void replace(T elem, int position) {
        if (datas != null && datas.size() > position) {
            datas.set(position, elem);
            notifyItemChanged(position);
        }
    }

    public void removeAll() {
        datas.clear();
        notifyDataSetChanged();
    }

    public void remove(T elem) {
        if (elem != null) {
            datas.remove(elem);
            notifyDataSetChanged();
        }
    }

    public List<T> getDatas() {
        return datas;
    }

}
