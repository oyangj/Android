package com.lewanjia.dancelog;

import android.os.Environment;

/**
 * Created by LS on 2018/3/17.
 */

public class Config {

    //上线重置 并且设置HttpUtils 和SpalshAct测试代码 LogActivity
    //ResponseHandler 修改 UrlConstants
    public static final boolean DEBUG = true;

    public static final long PULL_DOWN_REFRESH_DELAY = 100;
    public static final long PULL_DOWN_REFRESH_DELAY_1500 = 1000;

    public static final String PHOTO_AUTHORITY = "com.lewanjia.dancelog.provider";
    public static final String PHOTO_PATH = Environment.getExternalStorageDirectory() + "/"
            + MyApplication.getContext().getPackageName() + "/photos/";
    public static final String IMAGE_PATH = Environment.getExternalStorageDirectory() + "/"
            + MyApplication.getContext().getPackageName() + "/images/";

    public static final String WECHAT_APPID = "wxb4ae2ac65a682266";

    public static final String VIDEO_PATH = Environment.getExternalStorageDirectory() + "/"
            + MyApplication.getContext().getPackageName() + "/video/";

    public static String apiKey = "替换为你的apiKey(ak)";
    public static String secretKey = "替换为你的secretKey(sk)";
    public static String licenseID = "FaceFaceFaceFace-face-android";
    public static String licenseFileName = "替换为你的license文件";

}
