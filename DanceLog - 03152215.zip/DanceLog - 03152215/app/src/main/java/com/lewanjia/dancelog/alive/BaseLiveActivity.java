package com.lewanjia.dancelog.alive;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.lewanjia.dancelog.MyApplication;
import com.lewanjia.dancelog.R;
import com.lewanjia.dancelog.base.BaseActivity;
import com.lewanjia.dancelog.event.NetEvent;
import com.lewanjia.dancelog.event.ShowPop;
import com.lewanjia.dancelog.http.UrlConstants;
import com.lewanjia.dancelog.model.LiveChatInfo;
import com.lewanjia.dancelog.ui.adapter.LiveContentAdapter2;
import com.lewanjia.dancelog.ui.views.LiveRoomDialog;
import com.lewanjia.dancelog.ui.views.LiveShareDialog;
import com.lewanjia.dancelog.utils.ClassUtil;
import com.lewanjia.dancelog.utils.Constants;
import com.lewanjia.dancelog.utils.DataConstants;
import com.lewanjia.dancelog.utils.JsonUtils;
import com.lewanjia.dancelog.utils.LogUtils;
import com.lewanjia.dancelog.utils.LoginUtils;
import com.lewanjia.dancelog.utils.PreferencesUtils;
import com.lewanjia.dancelog.utils.SocketUtils;
import com.lewanjia.dancelog.utils.ToastUtils;
import com.loopj.android.http.RequestParams;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import io.socket.client.Socket;
import io.socket.emitter.Emitter;

/**
 * @author herozii
 * @version 1.0
 * @date 2020/2/13
 */
public abstract class BaseLiveActivity extends BaseActivity implements View.OnClickListener {

    public RecyclerView recyclerView;
    public TextView chatEt;
    RelativeLayout rl_bottom;
    RelativeLayout rl_content;

    public LiveContentAdapter2 liveContentAdapter2;
    public LiveRoomDialog liveRoomDialog;

    public Socket mSocket;
    public boolean firstEnter = false;
    public LinearLayoutManager linearLayoutManager;
    InputDialog inputDialog;

    public List<LiveChatInfo> liveChatInfos = new ArrayList<>();
    public static String TYPE_ONLINE = "online";
    public static String TYPE_OFFLINE = "offline";
    public static int onLineNum = 0;
    public static int offLineNum = 0;

    String roomid;
    String pic;
    String name;
    String head;
    private boolean isConnecting = false;
    private boolean isJoin = false;
    private static final long HEART_BEAT_RATE = 15 * 1000;
    private Handler mHandler = new Handler();
    private long least_sendTime = 5 * 1000;


    private Runnable heartBeatRunnable = new Runnable() {

        private long sendTime;

        @Override
        public void run() {
            if (System.currentTimeMillis() - sendTime >= HEART_BEAT_RATE) {
                if (mSocket != null) {
                    if (mSocket.connected())
                        mSocket.emit("", "");//发送一个空消息给服务器，通过发送消息的成功失败来判断长连接的连接状态
                } else {
                    mSocket.connect();
                }
                sendTime = System.currentTimeMillis();
            }
            mHandler.postDelayed(this, HEART_BEAT_RATE);//每隔一定的时间，对长连接进行一次心跳检测
        }
    };


    int time = 0;
    int price;


    @Override
    protected boolean showTitleBar() {
        return false;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

    }


    public void doRequestRoomNum(String type) {
        RequestParams requestParams = new RequestParams();
        roomid = getIntent().getStringExtra("room_id");
        requestParams.put("room_id", roomid);
        requestParams.put("type", type);
        sendRequest(getRequestUrl(UrlConstants.GET_ROOM_USER), requestParams, "", type);
    }

    public void doRequestPayNum() {
        RequestParams requestParams = new RequestParams();
        roomid = getIntent().getStringExtra("room_id");
        requestParams.put("room_id", roomid);
        sendRequest(getRequestUrl(UrlConstants.GET_LIVE_PAY_USER), requestParams, "");
    }

    public void doRequestQuestionList() {
        RequestParams requestParams = new RequestParams();
        roomid = getIntent().getStringExtra("room_id");
        requestParams.put("room_id", roomid);
        sendRequest(getRequestUrl(UrlConstants.GET_QUESTION_LIST), requestParams, "");
    }


    public void initDialog() {
        inputDialog = new InputDialog(BaseLiveActivity.this);
        inputDialog.setmOnTextSendListener(new InputDialog.OnTextSendListener() {
            @Override
            public void onTextSend(String msg) {
                //发送消息

                //更新数据
                if (!TextUtils.isEmpty(msg)) {
                    attemptSend(msg);
                    setVisible();
                }

            }
        });
        inputDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                setVisible();
            }
        });
        inputDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                setVisible();
            }
        });

    }

    boolean ispay;

    public void init() {
        price = getIntent().getIntExtra("price", 0);
        ispay = getIntent().getBooleanExtra("ispay", false);
        findView();
        initView2();

        if (price > 0 && !ispay) {
            //未付费
            LogUtils.i("hrx", "-未付费-");
            chatEt.setText("试看禁言");
            chatEt.setClickable(false);
        } else {
            //已付费 免费
            LogUtils.i("hrx", "-已付费 免费-");
            initSocket();
            chatEt.setText("跟老师互动吧~");
            chatEt.setClickable(true);
        }

        initDialog();


    }

    public void setVisible() {
        if (inputDialog != null) {
            if (inputDialog.isShowing()) {
                if (rl_bottom != null) {
                    rl_bottom.setVisibility(View.INVISIBLE);
                    return;
                }
            }
        }
        rl_bottom.setVisibility(View.VISIBLE);
    }

    private void initSocket() {
        if (!TextUtils.isEmpty(PreferencesUtils.getString(BaseLiveActivity.this, Constants.Shareprefrence.ROOM_SERVER_URL))) {
            LogUtils.i("hrx", "--" + PreferencesUtils.getString(BaseLiveActivity.this, Constants.Shareprefrence.ROOM_SERVER_URL));
            mSocket = SocketUtils.getSocket("http://47.115.58.155:3001/");
        }
        if (mSocket == null)
            return;


        mSocket.on(Socket.EVENT_CONNECT, onConnect);
        mSocket.on(Socket.EVENT_CONNECTING, new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                LogUtils.i("hrx", "-Connecting-" + Thread.currentThread() + mSocket.toString());
                isConnecting = true;
                EventBus.getDefault().post(new ShowPop(true));
            }
        });
//        mSocket.on(Socket.EVENT_DISCONNECT, onDisconnect);
        mSocket.on(Socket.EVENT_CONNECT_ERROR, onDisconnect);
        mSocket.on(Socket.EVENT_CONNECT_TIMEOUT, onDisconnect);
        mSocket.on(Socket.EVENT_RECONNECT, new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                LogUtils.i("hrx", "-reConnecting-" + Thread.currentThread() + mSocket.toString());
            }
        });
        mSocket.on("msg", onMessage);
        if (!mSocket.connected()) {
            LogUtils.i("hrx", "--connect--");
            mSocket.connect();
        }
        mHandler.postDelayed(heartBeatRunnable, HEART_BEAT_RATE);
    }

    private void initView2() {
        liveContentAdapter2 = new LiveContentAdapter2(this);
        linearLayoutManager = new LinearLayoutManager(this);
//        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        liveContentAdapter2.setLiveChatInfos(liveChatInfos);
        recyclerView.setAdapter(liveContentAdapter2);

    }


    private void findView() {
        pic = getIntent().getStringExtra("pic");
        rl_bottom = findViewById(R.id.rl_bottom);
        rl_content = findViewById(R.id.rl_content);
        findViewById(R.id.iv_share).setOnClickListener(this);
        findViewById(R.id.tv_more).setOnClickListener(this);
        recyclerView = findViewById(R.id.rv);
        chatEt = findViewById(R.id.et_chat);
        chatEt.setOnClickListener(this);
        findViewById(R.id.ll_bottom).setOnClickListener(this);
        findViewById(R.id.iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exit();
            }
        });
        liveShareDialog = findViewById(R.id.dialog);

    }

    public abstract void exit();

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_more:
                LogUtils.i("hrx", "--tv_more--");
                if (this instanceof LivePushActivity) {
                    if (liveRoomDialog == null) {
                        doRequestPayNum();
                        doRequestRoomNum(TYPE_OFFLINE);
                    } else if (liveRoomDialog != null && !liveRoomDialog.isVisible()) {
                        doRequestPayNum();
                        doRequestRoomNum(TYPE_OFFLINE);
                    }
                } else {
                    if (liveRoomDialog == null) {
                        doRequestRoomNum(TYPE_ONLINE);
                        doRequestRoomNum(TYPE_OFFLINE);
                    } else if (liveRoomDialog != null && !liveRoomDialog.isVisible()) {
                        doRequestRoomNum(TYPE_ONLINE);
                        doRequestRoomNum(TYPE_OFFLINE);
                    }
                }

                break;
            case R.id.ll_bottom:
                LogUtils.i("hrx", "--ll_bottom--");
                doRequestRoomNum(TYPE_ONLINE);
                doRequestRoomNum(TYPE_OFFLINE);
                break;
            case R.id.et_chat:
                rl_bottom.setVisibility(View.INVISIBLE);
                if (inputDialog != null) {
                    inputDialog.show();
                }
                break;

            case R.id.iv_share:
                showShare();
                try {
                    setView();
                } catch (Exception e) {

                }

                break;
        }
    }

    private void setView() {
        if (this instanceof LivePlayActivity) {
            if (liveShareDialog != null) {
                name = getIntent().getStringExtra("name");
                head = getIntent().getStringExtra("head");
                liveShareDialog.initView(name, roomid, head, pic,
                        PreferencesUtils.getString(BaseLiveActivity.this, Constants.apk_img));
            }
        }
        if (this instanceof LivePushActivity) {
            if (liveShareDialog != null) {
                if (!TextUtils.isEmpty(MyApplication.getInstance().getHeaderUrl()) && !TextUtils.isEmpty(MyApplication.getInstance().getUserName())) {
                    liveShareDialog.initView(MyApplication.getInstance().getUserName(), roomid,
                            MyApplication.getInstance().getHeaderUrl(), pic,
                            PreferencesUtils.getString(BaseLiveActivity.this, Constants.apk_img));
                }
            }
        }
    }

    public void showDialog() {
        if (this instanceof LivePushActivity) {
            liveRoomDialog = new LiveRoomDialog(this, roomid, true);
        } else {
            liveRoomDialog = new LiveRoomDialog(this, roomid, false);
        }

        liveRoomDialog.show(getSupportFragmentManager(), "tag");
        if (liveRoomDialog != null) {
            liveRoomDialog.notifyNavigator();
        }


    }


    LiveShareDialog liveShareDialog;

    public void showShare() {
//        liveShareDialog = new LiveShareDialog(BaseLiveActivity.this);
//        liveShareDialog.show();
        if (liveShareDialog != null && liveShareDialog.getVisibility() == View.GONE) {
            liveShareDialog.setVisibility(View.VISIBLE);
        }
    }

    Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            isConnecting = false;
            LogUtils.i("hrx", "-onConnect-" + Thread.currentThread() + mSocket.toString());
            EventBus.getDefault().post(new ShowPop(false));
//            progressDialog.dismiss();
            try {
                if (mSocket != null) {
                    isJoin = true;
                    SocketUtils.join(mSocket, roomid);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
//                    LogUtils.i("hrx", "-onConnect-" + Thread.currentThread() + mSocket.toString());
////                    if (!TextUtils.isEmpty(roomid)) {
////                        if (mSocket != null) {
////                            SocketUtils.join(mSocket, roomid);
//////                                join(mSocket, roomid);
////                        }
////                    }
//                    if (!firstEnter) {
//                        if (!TextUtils.isEmpty(roomid)) {
//                            if (mSocket != null) {
//                                SocketUtils.join(mSocket, roomid);
////                                join(mSocket, roomid);
//                            }
//                        }
//                        if (BaseLiveActivity.this instanceof LivePlayActivity) {
//                            attemptSendEnter();
//                            firstEnter = true;
//                        }
//                        if (BaseLiveActivity.this instanceof LivePushActivity) {
//                            doSendEnter();
//                            firstEnter = true;
//                        }
//                    }

//                    ToastUtils.show(BaseLiveActivity.this, "重连成功!");
                    if (!firstEnter) {
                        if (!TextUtils.isEmpty(roomid)) {
                            if (mSocket != null) {
                                try {
                                    if (BaseLiveActivity.this instanceof LivePlayActivity) {
                                        attemptSendEnter();
                                        firstEnter = true;
                                    }
                                    if (BaseLiveActivity.this instanceof LivePushActivity) {
                                        doSendEnter();
                                        firstEnter = true;
                                    }
                                } catch (Exception e) {
                                    firstEnter = false;
                                    LogUtils.i("hrx", "--加入房间--" + e.getMessage());
                                }
//                                join(mSocket, roomid);
                            }
                        }

                    }

                }
            });
        }
    };


    @Override
    protected void onDestroy() {

        try {
            if (mSocket != null) {
                if (this instanceof LivePlayActivity) {
                    attemptSendExit();
                }
//                SocketUtils.leave(mSocket,roomid);
                mSocket.disconnect();
                mSocket.off();
            }
        } catch (Exception e) {

        }

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onDestroy();

    }

    @Override
    protected void onResume() {
        super.onResume();
//        if (mSocket != null) {
//            if (!mSocket.connected()) {
//                mSocket.connect();
//            }
//        }
    }

    Emitter.Listener onMessage = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {

            //接收消息
            runOnUiThread(new Runnable() {
                @Override
                public void run() {

                    if (args != null && args.length > 0) {
                        LiveChatInfo chatInfo = null;

                        if (args.length > 1) {
                            LogUtils.i("hrx", "-onMessage-接收消息-" + args[0] + args[1]);
                            chatInfo = JsonUtils.toBean(args[1].toString(), LiveChatInfo.class);

                        }
//                        liveContentAdapter2.add(chatInfo);
                        if (chatInfo == null) return;

                        if (!TextUtils.isEmpty(chatInfo.user_id) &&
                                LoginUtils.getToken(BaseLiveActivity.this) != null &&
                                !chatInfo.user_id.equals(LoginUtils.getToken(BaseLiveActivity.this))) {
                            addData(chatInfo);
                            scroll();
                        }
                    }
                }
            });
        }
    };

    private Emitter.Listener onDisconnect = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            LogUtils.i("hrx", "-onDisconnect-" + args[0].toString());
            isConnecting = false;
            isJoin = false;
            EventBus.getDefault().post(new ShowPop(true));
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mSocket != null) {
                        if (time >= 3) {
//                            ToastUtils.show(BaseLiveActivity.this, "聊天连接失败，请退出重连");
                        } else {
                            time++;
                            if (!mSocket.connected()) {
                                if (!isConnecting) {
                                    mSocket.connect();
                                }
                            }
                        }

                    }
                }
            });
        }
    };


    private void attemptSend(String message) {
        if (mSocket == null) {
            return;
        } else {
            if (!mSocket.connected()) {
                mSocket.connect();
            }
        }
        LiveChatInfo chatInfo = new LiveChatInfo();
        chatInfo.message = message;
        chatInfo.user_id = LoginUtils.getToken(BaseLiveActivity.this) == null ? "" : LoginUtils.getToken(BaseLiveActivity.this);
        chatInfo.date = ClassUtil.getCurrentTime();
        liveContentAdapter2.add(chatInfo);
        scroll();
        if (!TextUtils.isEmpty(MyApplication.getInstance().getHeaderUrl()) && !TextUtils.isEmpty(MyApplication.getInstance().getUserName())) {
            chatInfo.pic = MyApplication.getInstance().getHeaderUrl();
            chatInfo.name = MyApplication.getInstance().getUserName();
        }
        chatInfo.type = LiveContentAdapter2.TYPE_CHAT;
//        addData(chatInfo);
        addData(chatInfo);
        scroll();
        // perform the sending message attempt.
        String json = JsonUtils.toJSONString(chatInfo);
        doRequestSaveLiveChat(chatInfo);
        LogUtils.i("hrx", "-attemptSend-" + json);
        least_sendTime = System.currentTimeMillis();
        mSocket.emit("message", json);
    }

    public void addData(LiveChatInfo liveChatInfo) {
        if (liveChatInfo != null) {
            //添加
            DataConstants.remove(liveChatInfos);
            liveChatInfos.add(liveChatInfo);
            liveContentAdapter2.notifyDataSetChanged();

//            liveContentAdapter2.notifyDataSetChanged();
            if (!TextUtils.isEmpty(roomid)) {
                DataConstants.chatInfos.put(roomid, liveChatInfos);
            }
        }
    }


    private void attemptSendEnter() {
        if (mSocket == null || !mSocket.connected()) return;
        LiveChatInfo chatInfo = new LiveChatInfo();
        chatInfo.user_id = LoginUtils.getToken(BaseLiveActivity.this) == null ? "" : LoginUtils.getToken(BaseLiveActivity.this);
        chatInfo.date = ClassUtil.getCurrentTime();
        if (!TextUtils.isEmpty(MyApplication.getInstance().getHeaderUrl())) {
            chatInfo.pic = MyApplication.getInstance().getHeaderUrl();
        }
        if (!TextUtils.isEmpty(MyApplication.getInstance().getUserName())) {
            chatInfo.name = MyApplication.getInstance().getUserName();
        }
        if (!TextUtils.isEmpty(MyApplication.getInstance().getUserId())) {
            chatInfo.id = MyApplication.getInstance().getUserId();
        }
        chatInfo.type = LiveContentAdapter2.TYPE_ENTER;
        String json = JsonUtils.toJSONString(chatInfo);
//        addData(chatInfo);
        addData(chatInfo);
        doRequestSaveLiveChat(chatInfo);
        scroll();
        // perform the sending message attempt.
        LogUtils.i("hrx", "-attemptSendEnter-" + json);
        mSocket.emit("message", json);

    }

    public void doSendEnter() {
        LiveChatInfo chatInfo = new LiveChatInfo();
        chatInfo.user_id = LoginUtils.getToken(BaseLiveActivity.this) == null ? "" : LoginUtils.getToken(BaseLiveActivity.this);
        chatInfo.date = ClassUtil.getCurrentTime();
        if (!TextUtils.isEmpty(MyApplication.getInstance().getHeaderUrl())) {
            chatInfo.pic = MyApplication.getInstance().getHeaderUrl();
        }
        if (!TextUtils.isEmpty(MyApplication.getInstance().getUserName())) {
            chatInfo.name = MyApplication.getInstance().getUserName();
        }
        if (!TextUtils.isEmpty(MyApplication.getInstance().getUserId())) {
            chatInfo.id = MyApplication.getInstance().getUserId();
        }
        chatInfo.type = LiveContentAdapter2.TYPE_ENTER;
        String json = JsonUtils.toJSONString(chatInfo);
        doRequestSaveLiveChat(chatInfo);
    }

    public void doSendExit() {
        LiveChatInfo chatInfo = new LiveChatInfo();
        chatInfo.user_id = LoginUtils.getToken(BaseLiveActivity.this) == null ? "" : LoginUtils.getToken(BaseLiveActivity.this);
        chatInfo.date = ClassUtil.getCurrentTime();
        if (!TextUtils.isEmpty(MyApplication.getInstance().getHeaderUrl())) {
            chatInfo.pic = MyApplication.getInstance().getHeaderUrl();
        }
        if (!TextUtils.isEmpty(MyApplication.getInstance().getUserName())) {
            chatInfo.name = MyApplication.getInstance().getUserName();
        }
        if (!TextUtils.isEmpty(MyApplication.getInstance().getUserId())) {
            chatInfo.id = MyApplication.getInstance().getUserId();
        }
        chatInfo.type = LiveContentAdapter2.TYPE_EXIT;
        String json = JsonUtils.toJSONString(chatInfo);
        doRequestSaveLiveChat(chatInfo);
    }


    private void attemptSendExit() {
        if (mSocket == null || !mSocket.connected()) return;
        LiveChatInfo chatInfo = new LiveChatInfo();
        chatInfo.user_id = LoginUtils.getToken(BaseLiveActivity.this) == null ? "" : LoginUtils.getToken(BaseLiveActivity.this);
        chatInfo.date = ClassUtil.getCurrentTime();
        if (!TextUtils.isEmpty(MyApplication.getInstance().getHeaderUrl())) {
            chatInfo.pic = MyApplication.getInstance().getHeaderUrl();
        }
        if (!TextUtils.isEmpty(MyApplication.getInstance().getUserName())) {
            chatInfo.name = MyApplication.getInstance().getUserName();
        }
        if (!TextUtils.isEmpty(MyApplication.getInstance().getUserId())) {
            chatInfo.id = MyApplication.getInstance().getUserId();
        }
        chatInfo.type = LiveContentAdapter2.TYPE_EXIT;
        String json = JsonUtils.toJSONString(chatInfo);
        doRequestSaveLiveChat(chatInfo);
//        addData(chatInfo);
        addData(chatInfo);
        scroll();
        // perform the sending message attempt.
        LogUtils.i("hrx", "-attemptSendExit-" + json);
        mSocket.emit("message", json);
    }

    public void scroll() {
        try {
//            RecyclerView.SmoothScroller smoothScroller = new LinearSmoothScroller(this) {
//                @Override
//                protected int getVerticalSnapPreference() {
//                    return LinearSmoothScroller.SNAP_TO_START;
//                }
//            };
//            if (liveContentAdapter2.getDatas().size() >= 1) {
//                smoothScroller.setTargetPosition(liveContentAdapter2.getDatas().size() - 1);
//            }
//            linearLayoutManager.startSmoothScroll(smoothScroller);
            if (recyclerView != null) {
                if (liveContentAdapter2 != null && liveContentAdapter2.getDatas() != null
                        && liveContentAdapter2.getDatas().size() >= 1) {
                    recyclerView.smoothScrollToPosition(liveContentAdapter2.getDatas().size() - 1);
                }
            }
        } catch (Exception e) {

        }

    }

    public void doRequestSaveLiveChat(LiveChatInfo chatInfo) {
        RequestParams requestParams = new RequestParams();
        if (TextUtils.isEmpty(roomid) || chatInfo == null) {
            LogUtils.i("hrx", "-v2/api/live/save-visit-live-record-");
            return;
        }
        requestParams.put("room_id", roomid);

        requestParams.put("name", chatInfo.name == null ? "" : chatInfo.name);
        requestParams.put("message", chatInfo.message == null ? "" : chatInfo.message);
        requestParams.put("date", chatInfo.date == null ? "" : chatInfo.date);
        requestParams.put("pic", chatInfo.pic == null ? "" : chatInfo.pic);
        requestParams.put("type", chatInfo.type);
        if (!TextUtils.isEmpty(chatInfo.user_id)) {
            requestParams.put("uid", chatInfo.user_id);
            requestParams.put("user_id", chatInfo.user_id);
        } else {
            if (!TextUtils.isEmpty(LoginUtils.getToken(BaseLiveActivity.this))) {
                requestParams.put("uid", LoginUtils.getToken(BaseLiveActivity.this));
                requestParams.put("user_id", LoginUtils.getToken(BaseLiveActivity.this));
            }
        }

        sendRequest(getRequestUrl(UrlConstants.SAVE_VISIT_LIVE_RECORD), requestParams);

    }

    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
    public void getStickyEvent(NetEvent event) {
        LogUtils.i("hrx", "收到联网消息" + event.isConnected);
        if (event instanceof NetEvent) {
            NetEvent netEvent = (NetEvent) event;
            if (netEvent.isConnected) {
                if (mSocket != null) {
                    if (mSocket != null && !mSocket.connected()) {
                        if (!isConnecting) {
                            EventBus.getDefault().post(new ShowPop(true));
                            mSocket.connect();
                            rePlay();
                        }
                    }
                }
            } else {
                isConnecting = false;
                isJoin = false;
                stopPlay();
                EventBus.getDefault().post(new ShowPop(true));
                ToastUtils.show(BaseLiveActivity.this, "请检查网络连接");
            }
        }

    }

    public void rePlay() {

    }

    public void stopPlay() {

    }

}
