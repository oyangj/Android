package com.lewanjia.dancelog.base;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.lansosdk.videoeditor.MediaInfo;
import com.lansosdk.videoeditor.VideoEditor;
import com.lansosdk.videoeditor.onVideoEditorProgressListener;
import com.lewanjia.dancelog.R;
import com.lewanjia.dancelog.ui.video.PreAddVideoActivity;
import com.lewanjia.dancelog.utils.LogUtils;
import com.lewanjia.dancelog.utils.ToastUtils;
import com.lewanjia.dancelog.utils.Utils;

import java.io.File;
import java.io.FileOutputStream;

/**
 * @author herozii
 * @version 1.0
 * @date 2019/12/27
 */
public class BaseCompressActivity extends BaseActivity {


    private ProgressDialog videoProgress;

    private static String videoDirPath;

    private VideoEditor mEditor;
    public volatile boolean isRunning = false;
    private ProgressBar progressBar;
    private TextView progressTv;

    String path;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        init();
        Utils.hideBottomUIMenu(this);
    }




    private void init() {
//        videoPath = getIntent().getStringExtra("videoPath");


        mEditor = new VideoEditor();

        mEditor.setOnProgessListener(new onVideoEditorProgressListener() {

            @Override
            public void onProgress(VideoEditor v, int percent) {
                if (progressDialog != null) {
                    progressTv.setText("正在处理中（" + String.valueOf(percent) + "%）");
                    progressBar.setProgress(percent);
                }
            }
        });
    }


    private ProgressDialog showProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        progressDialog = new ProgressDialog(this, R.style.DialogTheme);
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        if (!isFinishing()) {
            progressDialog.show();
        }
        progressDialog.setContentView(R.layout.progress_horizontal_dialog_layout);
        progressTv = progressDialog.findViewById(R.id.tv);
        progressTv.setText("正在处理中（0%）");
        progressBar = progressDialog.findViewById(R.id.progress);
        return progressDialog;
    }

    private void cancelProgressDialog() {
        if (progressDialog != null) {
            progressDialog.cancel();
            progressDialog = null;
        }
    }

    /**
     * 异步执行
     */
    public class SubAsyncTask extends AsyncTask<String, Object, String> {
        @Override
        protected void onPreExecute() {
            showProgressDialog();
            isRunning = true;
            super.onPreExecute();
        }

        @Override
        protected synchronized String doInBackground(String... params) {
            String videoPath = params[0];
            String path = null;
            while (path == null) {
                path = doVideoScale(mEditor, videoPath, 720, 1080);
            }
            return path;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            cancelProgressDialog();
            isRunning = false;
            if (!TextUtils.isEmpty(result)) {
                LogUtils.i("hrx","-视频地址-"+ result);
                onPostExecuteResult(result);
            }else {
                ToastUtils.show(BaseCompressActivity.this, "视频处理失败");
            }


        }
    }

    public void onPostExecuteResult(String result){

    }


    private String addWatermark(VideoEditor editor, String srcVideo) {
        MediaInfo info = new MediaInfo(srcVideo);
        if (info.prepare()) {
            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_watermark);
            String imgPath = videoDirPath + "/ic_watermark.png";
            File file = new File(imgPath);
            try {
                FileOutputStream out = new FileOutputStream(file);
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                out.flush();
                out.close();
            } catch (Exception e) {
            }

            MediaMetadataRetriever retr = new MediaMetadataRetriever();
            retr.setDataSource(srcVideo);
            String height = retr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            String width = retr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);

            int watermarkMargin = (int) getResources().getDimension(R.dimen.pager_margin_horizontal);

            int y = Integer.valueOf(height) - watermarkMargin - bitmap.getHeight();
            int x = Integer.valueOf(width) - watermarkMargin - bitmap.getWidth();
            MediaInfo mediaInfo = new MediaInfo(srcVideo);
//            if (mediaInfo.prepare()) {
//                editor.setEncodeBitRate((int) (mediaInfo.vBitRate * 0.9));//新加的
//            }
            return editor.executeOverLayVideoFrame(srcVideo, imgPath, x, y);
        } else {
            return null;
        }
    }

    public static String doVideoScale(VideoEditor editor, String srcVideo, int width, int height) {
        MediaInfo info = new MediaInfo(srcVideo);

        if (info.prepare()) {

//            editor.setEncodeBitRate((int) (VideoLayout.getSuggestBitRate(width * height) * 0.9f));
            return editor.executeScaleVideoFrame(srcVideo, VideoEditor.make16Closest(width), VideoEditor.make16Closest(height));
        } else {
            return null;
        }
    }


    @Override
    protected boolean showTitleBar() {
        return false;
    }

    public static Intent actionToView(Context context, String videoPath, int actionType) {
        Intent intent = new Intent(context, PreAddVideoActivity.class);
        intent.putExtra("videoPath", videoPath);
//        intent.putExtra("thumbPath", thumbPath);
        intent.putExtra("actionType", actionType);
        return intent;
    }

}
