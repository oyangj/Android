package com.aliyun.svideo.base.Form;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

public class AspectForm {
    private int aspect;
    private String download;
    private String md5;
    private String path;

    public AspectForm() {
    }

    public int getAspect() {
        return this.aspect;
    }

    public void setAspect(int aspect) {
        this.aspect = aspect;
    }

    public String getDownload() {
        return this.download;
    }

    public void setDownload(String download) {
        this.download = download;
    }

    public String getMd5() {
        return this.md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}

