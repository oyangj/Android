package com.aliyun.svideo.base.widget.beauty.listener;

/**
 * Created by Akira on 2018/5/30.
 */

public interface OnBeautyShapeItemSeletedListener {

    void onItemSelected(int postion);
}
