package com.aliyun.svideo.base.widget.beauty.listener;

/**
 * 微调按钮点击接口
 */
public interface OnBeautyDetailClickListener {
    void onDetailClick();
}
