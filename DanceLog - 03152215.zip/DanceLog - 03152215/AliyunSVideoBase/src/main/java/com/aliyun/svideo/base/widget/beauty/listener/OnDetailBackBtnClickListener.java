package com.aliyun.svideo.base.widget.beauty.listener;

public interface OnDetailBackBtnClickListener {
    void onBackClick();
}
