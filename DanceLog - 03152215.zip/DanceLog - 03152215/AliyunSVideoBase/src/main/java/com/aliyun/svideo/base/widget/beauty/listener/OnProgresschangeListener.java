package com.aliyun.svideo.base.widget.beauty.listener;

/**
 * Created by Akira on 2018/5/31.
 */

public interface OnProgresschangeListener {

    void onProgressChange(int progress);
}
