package com.aliyun.svideo.base.widget.beauty.listener;

import com.aliyun.svideo.base.widget.beauty.BeautyParams;
import com.aliyun.svideo.base.widget.beauty.sharp.BeautyShapeParams;

/**
 * Created by Akira on 2018/5/31.
 */

public interface OnBeautyShapeParamsChangeListener {

    void onBeautyChange(BeautyShapeParams param);
}
